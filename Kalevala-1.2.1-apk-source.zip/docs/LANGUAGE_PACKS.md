# Offline language packs

Each checked-in JSON pack is self-describing and follows schema version 1:

```json
{
  "schemaVersion": 1,
  "id": "fi",
  "name": "Suomi",
  "work": "Kalevala (1849)",
  "compiler": "Elias Lönnrot",
  "translator": null,
  "sourceUrl": "https://…",
  "sourceNote": "…",
  "sourceSha256": "…",
  "runes": [
    {
      "number": 1,
      "title": "Ensimmäinen runo",
      "lines": ["…"]
    }
  ]
}
```

`scripts/prepare_corpus.py` removes Project Gutenberg headers and footers, front matter, tables of contents, and non-rune appendices. It keeps the literary verse as ordered, non-empty display lines. English material after Rune 50, including Crawford's epilogue and glossary, is not represented as rune text.

`scripts/verify_corpus.py` rejects a pack unless it has schema version 1, the expected language identifier, exactly 50 sequentially numbered runes, no blank verse records, and the audited line total:

| Pack | Runes | Non-empty lines |
|---|---:|---:|
| Finnish | 50 | 22,796 |
| English | 50 | 22,255 |

The app repository is deliberately pack-aware: language selection, search results, saved positions, favourites, bookmarks, and TTS locale tags all include the language identifier. Adding another translation requires a checked-in pack plus a corresponding `LanguagePack` enum entry and translated reference-guide copy.
