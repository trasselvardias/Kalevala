# No project-specific shrinking rules are required.
