package com.elvispillinen.kalevala.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CoreLogicTest {
    @Test
    fun searchIgnoresFinnishDiacriticsAndCurlyApostrophes() {
        assertEquals("vainamoinen", SearchNormalizer.normalize("Väinämöinen"))
        assertEquals("saa'ani", SearchNormalizer.normalize("Saa’ani"))
        assertTrue(SearchNormalizer.matches("Vaka vanha Väinämöinen", "vainamoinen"))
    }

    @Test
    fun narrationChunksRespectTheLimitAndKeepAllLines() {
        val lines = listOf("Mieleni minun tekevi", "aivoni ajattelevi", "lähteäni laulamahan")
        val chunks = Narrator.speechChunks(lines, maxLength = 40)
        assertTrue(chunks.size > 1)
        assertTrue(chunks.all { it.length <= 40 })
        lines.forEach { line -> assertTrue(chunks.joinToString(" ").contains(line)) }
    }

    @Test
    fun referenceIdsAreUniqueAndStoryGuideCoversEveryRune() {
        assertEquals(ReferenceCatalog.entries.size, ReferenceCatalog.entries.map { it.id }.toSet().size)
        val covered = StoryGuides.arcs.flatMap { it.runes.toList() }
        assertEquals((1..50).toList(), covered)
        assertTrue(ReferenceCatalog.entries.size >= 200)
        assertTrue(ReferenceCatalog.entries.count { it.category == ReferenceCategory.Word } >= 140)
    }

    @Test
    fun glossaryRecognizesCoreForms() {
        assertEquals("word-laulamahan", ReferenceCatalog.lookupWord("laulamahan")?.id)
        assertEquals("sampo", ReferenceCatalog.lookupWord("Sampo")?.id)
        assertEquals("vainamoinen", ReferenceCatalog.lookupWord("Väinämöinen")?.id)
        assertEquals("word-sotka", ReferenceCatalog.lookupWord("sotkan")?.id)
        assertEquals("word-lyly", ReferenceCatalog.lookupWord("lylyä")?.id)
        assertEquals("word-ellos", ReferenceCatalog.lookupWord("Ellös")?.id)
        assertEquals("word-hvn-illative", ReferenceCatalog.lookupWord("tupahan")?.id)
        assertEquals("word-virkkoi", ReferenceCatalog.lookupWord("nimesi")?.id)
        assertEquals("pursi", ReferenceCatalog.lookupWord("purren")?.id)
        assertEquals("annikki", ReferenceCatalog.lookupWord("Annikki")?.id)
        assertNull(ReferenceCatalog.lookupWord("vene"))
        assertNull(ReferenceCatalog.lookupWord("hyväniminen"))
        assertNull(ReferenceCatalog.lookupWord("nopeasti"))
    }

    @Test
    fun lineLookupReturnsOnlyTermsThatHaveArticles() {
        val matches = ReferenceCatalog.matchesIn("Sotka lensi aivan nopeasti.")
        assertEquals(listOf("Sotka"), matches.map { it.surface })
        assertEquals(listOf("word-sotka"), matches.map { it.entry.id })
    }

    @Test
    fun narrativePartsCoverEveryRuneAndStayManageable() {
        for (number in 1..50) {
            val rune = Rune(number, "Rune $number", List(1_000) { "line" })
            val sections = RuneSections.sectionsFor(rune, LanguagePack.Finnish)
            assertTrue("Rune $number needs multiple parts", sections.size >= 2)
            assertEquals(0, sections.first().startLine)
            assertEquals(sections.map { it.startLine }.sorted().distinct(), sections.map { it.startLine })
            assertTrue(sections.all { it.summary.isNotBlank() })
            assertTrue(sections.all { it.summary.length >= 60 })
            assertTrue(sections.none { it.summary.startsWith("Tässä jaksossa") })
            sections.forEachIndexed { index, section ->
                val end = sections.getOrNull(index + 1)?.startLine ?: rune.lines.size
                assertTrue("Rune $number part is too long", end - section.startLine <= 180)
            }
        }

        val firstRune = Rune(1, "Ensimmäinen runo", List(344) { "line" })
        val finnish = RuneSections.sectionsFor(firstRune, LanguagePack.Finnish)
        assertTrue(finnish.any { it.startLine == 176 && it.title.contains("Sotka") })
        assertTrue(finnish.any { it.startLine == 280 && it.title.contains("rannan") })

        val englishRune = Rune(1, "Rune I", List(262) { "line" })
        val english = RuneSections.sectionsFor(englishRune, LanguagePack.English)
        assertEquals("Ilmatar descends into the sea", english.first().title)
        assertTrue(english.all { it.summary.length >= 60 })
    }

    @Test
    fun dailyVerseUsesCheckedBilingualAnchors() {
        val dates = (0L until 500L).map { LocalDate.ofEpochDay(it) }
        val anchors = dates.map(DailyVerseCatalog::anchorFor)

        assertTrue(anchors.all { it.runeNumber in 1..50 })
        assertEquals(110, anchors.first { it.runeNumber == 1 }.finnishLineIndex)
        assertEquals(0, anchors.first { it.runeNumber == 1 }.englishLineIndex)
        assertEquals(1, anchors.first { it.runeNumber == 49 }.finnishLineIndex)
        assertEquals(1, anchors.first { it.runeNumber == 49 }.englishLineIndex)
        assertTrue(anchors.all { it.lineIndex(LanguagePack.Finnish) >= 0 })
        assertTrue(anchors.all { it.lineIndex(LanguagePack.English) >= 0 })
    }
}
