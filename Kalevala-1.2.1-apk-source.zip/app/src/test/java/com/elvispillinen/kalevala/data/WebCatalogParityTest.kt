package com.elvispillinen.kalevala.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class WebCatalogParityTest {
    @Test
    fun browserCatalogMatchesAndroidSource() {
        val output = File("../web/data/catalog.json")
        val generated = catalogJson()
        if (System.getenv("UPDATE_WEB_DATA") == "1") {
            output.parentFile.mkdirs()
            output.writeText(generated)
        }
        assertTrue("Run UPDATE_WEB_DATA=1 to refresh web catalog", output.isFile)
        assertEquals(generated, output.readText())
    }

    private fun catalogJson(): String = buildString {
        append("{\"sections\":[")
        RuneSections.bilingualSections().forEachIndexed { i, s ->
            if (i > 0) append(',')
            append("{\"rune\":${s.runeNumber},\"fiStart\":${s.finnishStartLine},\"enStart\":${s.englishStartLine ?: "null"},")
            append("\"fiTitle\":${q(s.title.fi)},\"enTitle\":${q(s.title.en)},\"fiSummary\":${q(s.summary.fi)},\"enSummary\":${q(s.summary.en)}}")
        }
        append("],\"entries\":[")
        ReferenceCatalog.entries.forEachIndexed { i, e ->
            if (i > 0) append(',')
            append("{\"id\":${q(e.id)},\"category\":${q(e.category.name)},\"fiName\":${q(e.name.fi)},\"enName\":${q(e.name.en)},")
            append("\"fiShort\":${q(e.short.fi)},\"enShort\":${q(e.short.en)},\"fiDetail\":${q(e.detail.fi)},\"enDetail\":${q(e.detail.en)},\"aliases\":[")
            e.aliases.forEachIndexed { j, alias -> if (j > 0) append(','); append(q(alias)) }
            append("]}")
        }
        append("],\"arcs\":[")
        StoryGuides.arcs.forEachIndexed { i, a ->
            if (i > 0) append(',')
            append("{\"first\":${a.runes.first},\"last\":${a.runes.last},\"fiTitle\":${q(a.title.fi)},\"enTitle\":${q(a.title.en)},\"fiSummary\":${q(a.summary.fi)},\"enSummary\":${q(a.summary.en)}}")
        }
        append("],\"daily\":[")
        DailyVerseCatalog.bilingualAnchors().forEachIndexed { i, a ->
            if (i > 0) append(',')
            append("{\"rune\":${a.runeNumber},\"fiLine\":${a.finnishLineIndex},\"enLine\":${a.englishLineIndex}}")
        }
        append("]}\n")
    }

    private fun q(value: String): String = buildString {
        append('"')
        value.forEach { c -> when (c) {
            '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n")
            '\r' -> append("\\r"); '\t' -> append("\\t")
            else -> if (c.code < 32) append("\\u%04x".format(c.code)) else append(c)
        } }
        append('"')
    }
}
