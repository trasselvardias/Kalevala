package com.elvispillinen.kalevala.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.ReferenceEntry
import com.elvispillinen.kalevala.data.SearchHit
import com.elvispillinen.kalevala.data.SearchNormalizer
import com.elvispillinen.kalevala.ui.components.EmptyState
import com.elvispillinen.kalevala.ui.uiText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun SearchScreen(
    viewModel: KalevalaViewModel,
    contentPadding: PaddingValues,
    onOpenResult: (LanguagePack, Int, Int) -> Unit,
    onOpenReference: (String) -> Unit,
) {
    val language = viewModel.language
    var query by rememberSaveable { mutableStateOf("") }
    var allLanguages by rememberSaveable { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(emptyList<SearchHit>()) }
    val referenceResults = remember(query, language) {
        if (query.trim().length < 2) emptyList() else viewModel.references.filter { entry ->
            SearchNormalizer.matches(entry.name.fi, query) ||
                SearchNormalizer.matches(entry.name.en, query) ||
                SearchNormalizer.matches(entry.short(language), query) ||
                entry.aliases.any { SearchNormalizer.matches(it, query) }
        }.take(12)
    }

    LaunchedEffect(query, allLanguages, language) {
        if (query.trim().length < 2) {
            results = emptyList()
            loading = false
        } else {
            loading = true
            delay(180)
            results = withContext(Dispatchers.Default) { viewModel.search(query, allLanguages) }
            loading = false
        }
    }

    Box(Modifier.fillMaxSize().padding(contentPadding), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(uiText(language, "Hae Kalevalasta", "Search the Kalevala"), style = MaterialTheme.typography.headlineLarge)
                Text(
                    uiText(language, "Haku toimii kokonaan ilman verkkoyhteyttä.", "Full-text search works entirely offline."),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    label = { Text(uiText(language, "Sana, nimi tai säkeen osa", "Word, name, or part of a line")) },
                    singleLine = true,
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(uiText(language, "Molemmat kielet", "Both languages"), style = MaterialTheme.typography.labelLarge)
                        Text(
                            uiText(language, "Hae suomesta ja englannista", "Search Finnish and English"),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = allLanguages, onCheckedChange = { allLanguages = it })
                }
            }

            if (loading) {
                item { Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            }

            if (query.trim().length < 2) {
                item {
                    EmptyState(
                        uiText(language, "Kokeile esimerkiksi “Sampo”", "Try “Sampo”, for example"),
                        uiText(language, "Voit hakea täsmällisiä säkeitä, henkilöitä ja sanaston käsitteitä.", "Search exact lines, characters, and guide terms."),
                    )
                }
            } else if (!loading && results.isEmpty() && referenceResults.isEmpty()) {
                item { EmptyState(uiText(language, "Ei osumia", "No results"), uiText(language, "Kokeile lyhyempää hakusanaa tai molempia kieliä.", "Try a shorter query or enable both languages.")) }
            }

            if (referenceResults.isNotEmpty()) {
                item { Text(uiText(language, "Tietäjän hakemistossa", "In the reading guide"), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp)) }
                items(referenceResults, key = { "ref-${it.id}" }) { entry ->
                    ReferenceSearchCard(entry, language) { onOpenReference(entry.id) }
                }
            }

            if (results.isNotEmpty()) {
                item {
                    Text(
                        uiText(language, "Säkeissä (${results.size}${if (results.size == 150) "+" else ""})", "In the text (${results.size}${if (results.size == 150) "+" else ""})"),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                items(results, key = { "${it.language.code}-${it.runeNumber}-${it.lineIndex}" }) { hit ->
                    SearchResultCard(hit, language) { onOpenResult(hit.language, hit.runeNumber, hit.lineIndex) }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(hit: SearchHit, uiLanguage: LanguagePack, onClick: () -> Unit) {
    Card(onClick = onClick) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                "${hit.language.nativeName} · ${uiText(uiLanguage, "runo", "rune")} ${hit.runeNumber} · ${uiText(uiLanguage, "säe", "line")} ${hit.lineIndex + 1}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary,
            )
            Text(hit.line, style = MaterialTheme.typography.bodyLarge, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ReferenceSearchCard(entry: ReferenceEntry, language: LanguagePack, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(entry.name(language), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(entry.short(language), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
