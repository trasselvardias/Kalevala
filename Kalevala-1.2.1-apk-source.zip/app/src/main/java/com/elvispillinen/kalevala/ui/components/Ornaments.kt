package com.elvispillinen.kalevala.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val HANDS_PATH =
    "M564.39046,231.88629 L407.08123,231.82849 L295.76146,342.90879 L183.4879,231.86806 " +
        "L295.75659,124.11306 L325.74365,154.19945 L261.71282,220.50628 L291.33088,251.59813 " +
        "L403.79755,143.94108 L564.39046,143.79816 Z " +
        "M22.672021,144.00474 L179.98125,144.06254 L291.30102,32.982227 L403.57459,144.02297 " +
        "L291.30589,251.77797 L261.31883,221.69158 L325.34966,155.38475 L295.7316,124.2929 " +
        "L183.26493,231.94995 L22.672021,232.09287 Z"

@Composable
fun RunonlaulajaMark(
    modifier: Modifier = Modifier,
    contentDescription: String = "Runonlaulajan kädet",
) {
    val path = remember {
        PathParser().parsePathString(HANDS_PATH).toPath().apply {
            fillType = PathFillType.EvenOdd
        }
    }
    val color = MaterialTheme.colorScheme.tertiary
    val rimColor = MaterialTheme.colorScheme.onTertiary
    Canvas(
        modifier = modifier
            .aspectRatio(1.62f)
            .semantics { this.contentDescription = contentDescription },
    ) {
        val scaleX = size.width / 587f
        val scaleY = size.height / 376f
        scale(scaleX, scaleY, pivot = Offset.Zero) {
            drawPath(path, color = color)
            drawPath(
                path = path,
                color = rimColor,
                style = Stroke(width = 16f, join = StrokeJoin.Miter),
            )
        }
    }
}

@Composable
fun HannunvaakunaDivider(modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.tertiary
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Canvas(Modifier.weight(1f).height(1.dp)) { drawLine(color, Offset.Zero, Offset(size.width, 0f)) }
        Text(
            text = "⌘",
            modifier = Modifier.padding(horizontal = 12.dp),
            color = color,
            fontFamily = FontFamily.Serif,
            fontSize = 24.sp,
        )
        Canvas(Modifier.weight(1f).height(1.dp)) { drawLine(color, Offset.Zero, Offset(size.width, 0f)) }
    }
}

@Composable
fun HistoricalHakaristiDiagram(modifier: Modifier = Modifier, contentDescription: String) {
    val color = MaterialTheme.colorScheme.onSurface
    Box(modifier.semantics { this.contentDescription = contentDescription }) {
        Canvas(modifier = Modifier.matchParentSize().padding(12.dp)) {
            val unit = size.minDimension / 6f
            val center = Offset(size.width / 2f, size.height / 2f)
            val stroke = Stroke(width = unit * 0.65f, cap = StrokeCap.Square)
            val path = Path().apply {
                moveTo(center.x, center.y)
                lineTo(center.x, center.y - 2f * unit)
                lineTo(center.x + 2f * unit, center.y - 2f * unit)
                moveTo(center.x, center.y)
                lineTo(center.x + 2f * unit, center.y)
                lineTo(center.x + 2f * unit, center.y + 2f * unit)
                moveTo(center.x, center.y)
                lineTo(center.x, center.y + 2f * unit)
                lineTo(center.x - 2f * unit, center.y + 2f * unit)
                moveTo(center.x, center.y)
                lineTo(center.x - 2f * unit, center.y)
                lineTo(center.x - 2f * unit, center.y - 2f * unit)
            }
            drawPath(path, color, style = stroke)
        }
    }
}
