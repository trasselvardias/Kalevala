package com.elvispillinen.kalevala.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.ReferenceCategory
import com.elvispillinen.kalevala.data.ReferenceEntry
import com.elvispillinen.kalevala.data.SearchNormalizer
import com.elvispillinen.kalevala.ui.components.HannunvaakunaDivider
import com.elvispillinen.kalevala.ui.components.HistoricalHakaristiDiagram
import com.elvispillinen.kalevala.ui.components.RunonlaulajaMark
import com.elvispillinen.kalevala.ui.uiText

@Composable
fun ReferenceScreen(
    viewModel: KalevalaViewModel,
    contentPadding: PaddingValues,
    onOpenEntry: (String) -> Unit,
) {
    val language = viewModel.language
    var query by rememberSaveable { mutableStateOf("") }
    var category by remember { mutableStateOf<ReferenceCategory?>(null) }
    val entries = remember(query, category, language) {
        viewModel.references.filter { entry ->
            (category == null || entry.category == category) &&
                (query.isBlank() || SearchNormalizer.matches(entry.name.fi, query) ||
                    SearchNormalizer.matches(entry.name.en, query) ||
                    SearchNormalizer.matches(entry.short(language), query) ||
                    entry.aliases.any { SearchNormalizer.matches(it, query) })
        }.sortedWith(compareBy({ it.category.ordinal }, { it.name(language) }))
    }

    Box(Modifier.fillMaxSize().padding(contentPadding), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            item {
                Text("Tietäjä", style = MaterialTheme.typography.headlineLarge)
                Text(
                    uiText(
                        language,
                        "${viewModel.references.size} artikkelia sanoista, henkilöistä, paikoista, esineistä ja ajatuksista.",
                        "${viewModel.references.size} articles on words, characters, places, objects, and ideas.",
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    label = { Text(uiText(language, "Hae hakemistosta", "Search the guide")) },
                    singleLine = true,
                )
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        FilterChip(selected = category == null, onClick = { category = null }, label = { Text(uiText(language, "Kaikki", "All")) })
                    }
                    items(ReferenceCategory.entries) { item ->
                        FilterChip(selected = category == item, onClick = { category = item }, label = { Text(categoryName(item, language)) })
                    }
                }
                HannunvaakunaDivider(Modifier.padding(top = 10.dp))
            }

            items(entries, key = { it.id }) { entry ->
                Card(onClick = { onOpenEntry(entry.id) }) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(categoryName(entry.category, language), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                            Text(entry.name(language), style = MaterialTheme.typography.titleMedium)
                            Text(entry.short(language), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (entry.historicallySensitive) {
                            Icon(
                                Icons.Outlined.WarningAmber,
                                uiText(language, "Historiallisesti arkaluonteinen", "Historically sensitive"),
                                tint = MaterialTheme.colorScheme.secondary,
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    uiText(language, "Lukijan opas kuvaa ensisijaisesti vuoden 1849 Kalevalaa. Sanojen merkitys voi vaihdella säeyhteyden ja murteen mukaan, eikä opas korvaa kansanrunouden tai karjalaisten perinteiden tutkimusta.", "This reading guide primarily describes the 1849 Kalevala. Word meanings may vary with verse context and dialect, and the guide is not a substitute for scholarship on oral poetry or Karelian traditions."),
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
fun ReferenceDetailScreen(
    entry: ReferenceEntry,
    language: LanguagePack,
    onBack: () -> Unit,
    onOpenRune: (Int) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(entry.name(language), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, uiText(language, "Takaisin", "Back"))
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    Text(categoryName(entry.category, language), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    Text(entry.name(language), style = MaterialTheme.typography.headlineLarge)
                }
                if (entry.id == "symbol-hands") {
                    item {
                        RunonlaulajaMark(
                            Modifier.fillMaxWidth().padding(horizontal = 30.dp),
                            uiText(language, "Runonlaulajan käsien merkki", "Runo-singer's hands symbol"),
                        )
                    }
                }
                if (entry.id == "symbol-hannunvaakuna") {
                    item {
                        Text(
                            "⌘",
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.displayLarge,
                            color = MaterialTheme.colorScheme.tertiary,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
                if (entry.id == "symbol-hakaristi") {
                    item {
                        Card {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.WarningAmber, null, tint = MaterialTheme.colorScheme.secondary)
                                Text(
                                    uiText(language, "Historiallinen ja nykyisin erittäin arkaluonteinen tunnus", "Historical and now highly sensitive emblem"),
                                    modifier = Modifier.padding(start = 12.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                    item {
                        HistoricalHakaristiDiagram(
                            Modifier.fillMaxWidth().height(180.dp),
                            uiText(language, "Neutraali kaavio historiallisesta hakaristikuviosta", "Neutral diagram of the historical swastika motif"),
                        )
                    }
                }
                item { Text(entry.detail(language), style = MaterialTheme.typography.bodyLarge) }
                if (entry.aliases.isNotEmpty()) {
                    item {
                        Text(uiText(language, "Muita nimiä ja muotoja", "Other names and forms"), style = MaterialTheme.typography.titleMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                            items(entry.aliases) { alias -> AssistChip(onClick = {}, label = { Text(alias) }) }
                        }
                    }
                }
                entry.runes?.let { range ->
                    item {
                        Text(uiText(language, "Liittyvät runot", "Related runes"), style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { onOpenRune(range.first) }) {
                            Text(
                                if (range.first == range.last) uiText(language, "Avaa runo ${range.first}", "Open Rune ${range.first}")
                                else uiText(language, "Avaa runot ${range.first}–${range.last}", "Open Runes ${range.first}–${range.last}"),
                            )
                        }
                    }
                }
                item {
                    HannunvaakunaDivider()
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            uiText(language, "Hakemisto on lukemista tukeva tiivistelmä. Kalevala on Lönnrotin kirjallinen eepos, joka perustuu monialueiseen suulliseen runoperinteeseen.", "The guide is a reading aid. The Kalevala is Lönnrot's literary epic based on oral poetry from several regions."),
                            modifier = Modifier.padding(start = 10.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

private fun categoryName(category: ReferenceCategory, language: LanguagePack): String = when (category) {
    ReferenceCategory.Character -> uiText(language, "Henkilö", "Character")
    ReferenceCategory.Place -> uiText(language, "Paikka", "Place")
    ReferenceCategory.Object -> uiText(language, "Esine", "Object")
    ReferenceCategory.Concept -> uiText(language, "Käsite", "Concept")
    ReferenceCategory.Word -> uiText(language, "Vanha sana", "Old word")
    ReferenceCategory.Symbol -> uiText(language, "Symboli", "Symbol")
}
