package com.elvispillinen.kalevala.data

import java.text.Normalizer
import java.util.Locale

object SearchNormalizer {
    fun normalize(value: String): String = Normalizer.normalize(
        value.lowercase(Locale.ROOT)
            .replace('’', '\'')
            .replace('‘', '\'')
            .replace('`', '\''),
        Normalizer.Form.NFD,
    ).replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^\\p{L}\\p{N}']+"), " ")
        .trim()

    fun matches(value: String, query: String): Boolean {
        val needle = normalize(query)
        return needle.isNotBlank() && normalize(value).contains(needle)
    }

    fun cleanWord(value: String): String = value
        .trim { !it.isLetter() && it != '\'' && it != '’' && it != '-' }
        .lowercase(Locale.ROOT)
}
