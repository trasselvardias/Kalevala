package com.elvispillinen.kalevala.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.ui.components.EmptyState
import com.elvispillinen.kalevala.ui.uiText

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(
    viewModel: KalevalaViewModel,
    onBack: () -> Unit,
    onOpen: (LanguagePack, Int, Int) -> Unit,
) {
    val language = viewModel.language
    val bookmarks = viewModel.bookmarks.sortedWith(compareBy({ it.language.ordinal }, { it.runeNumber }, { it.lineIndex }))
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiText(language, "Kirjanmerkit", "Bookmarks")) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, uiText(language, "Takaisin", "Back")) }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            if (bookmarks.isEmpty()) {
                EmptyState(
                    uiText(language, "Ei vielä kirjanmerkkejä", "No bookmarks yet"),
                    uiText(language, "Napauta lukijassa säettä tallentaaksesi sen tai liittääksesi muistiinpanon.", "Tap a line in the reader to save it or attach a note."),
                    Modifier.widthIn(max = 640.dp),
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(bookmarks, key = { it.key }) { bookmark ->
                        val rune = viewModel.repository.rune(bookmark.language, bookmark.runeNumber)
                        val line = rune.lines.getOrNull(bookmark.lineIndex).orEmpty()
                        Card(onClick = { onOpen(bookmark.language, bookmark.runeNumber, bookmark.lineIndex) }) {
                            Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(
                                        "${bookmark.language.nativeName} · ${uiText(language, "runo", "rune")} ${bookmark.runeNumber} · ${uiText(language, "säe", "line")} ${bookmark.lineIndex + 1}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.secondary,
                                    )
                                    Text(line, style = MaterialTheme.typography.bodyLarge, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                    if (bookmark.note.isNotBlank()) {
                                        Text(
                                            bookmark.note,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                }
                                IconButton(onClick = { viewModel.toggleBookmark(bookmark.language, bookmark.runeNumber, bookmark.lineIndex) }) {
                                    Icon(Icons.Outlined.DeleteOutline, uiText(language, "Poista kirjanmerkki", "Delete bookmark"))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
