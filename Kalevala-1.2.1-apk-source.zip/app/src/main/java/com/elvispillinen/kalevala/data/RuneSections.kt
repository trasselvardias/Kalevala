package com.elvispillinen.kalevala.data

import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Semantic landmarks based on the line-ranged Arguments in W. F. Kirby's
 * 1907 edition. Finnish starts follow the 1849 text's numbering. Crawford's
 * translation is not line-for-line, so English starts are mapped to the same
 * episodes. Very long episodes are split again to keep reading manageable.
 */
object RuneSections {
    private const val maxLinesPerPart = 180

    private data class Spec(
        val fiStart: Int,
        val enStart: Int?,
        val title: LocalizedText,
    )

    private fun p(fi: Int, en: Int?, fiTitle: String, enTitle: String) =
        Spec(fi, en, LocalizedText(fiTitle, enTitle))

    fun bilingualSections(): List<BilingualRuneSection> = byRune.flatMap { (runeNumber, specs) ->
        specs.map { spec ->
            BilingualRuneSection(
                runeNumber = runeNumber,
                finnishStartLine = spec.fiStart,
                englishStartLine = spec.enStart,
                title = spec.title,
                summary = LocalizedText(
                    SectionSummaries.forSection(runeNumber, spec.fiStart, LanguagePack.Finnish).orEmpty(),
                    SectionSummaries.forSection(runeNumber, spec.fiStart, LanguagePack.English).orEmpty(),
                ),
            )
        }
    }

    private val byRune: Map<Int, List<Spec>> = mapOf(
        1 to listOf(
            p(0, null, "Runonlaulajan alkusanat", "Singer's prelude"),
            p(102, 0, "Ilmatar laskeutuu mereen", "Ilmatar descends into the sea"),
            p(176, 80, "Sotka rakentaa pesän", "The teal builds her nest"),
            p(212, 119, "Maailmanmuna särkyy", "The world egg breaks"),
            p(244, 154, "Ilmatar muovaa maailman", "Ilmatar shapes the world"),
            p(280, 193, "Väinämöinen syntyy ja saavuttaa rannan", "Väinämöinen is born and reaches shore"),
        ),
        2 to listOf(
            p(0, 0, "Sampsa kylvää puut", "Sampsa sows the trees"),
            p(42, 45, "Suuri tammi peittää taivaan", "The great oak covers the sky"),
            p(110, 119, "Pieni mies kaataa tammen", "The little man fells the oak"),
            p(224, 242, "Luonto puhkeaa kasvuun", "Nature bursts into growth"),
            p(256, 276, "Ohranjyvät löytyvät", "The barleycorns are found"),
            p(264, 285, "Kokko sytyttää kasken", "The eagle kindles the clearing"),
            p(284, 307, "Väinämöinen kylvää ohran", "Väinämöinen sows the barley"),
        ),
        3 to listOf(
            p(0, 0, "Väinämöisen maine kasvaa", "Väinämöinen's fame grows"),
            p(20, 23, "Väinämöisen ja Joukahaisen kilpalaulanta", "The singing contest"),
            p(330, 373, "Joukahainen lupaa Ainon", "Joukahainen promises Aino"),
            p(476, 538, "Joukahainen palaa kotiin", "Joukahainen returns home"),
            p(524, 593, "Aino kuulee kohtalostaan", "Aino hears her fate"),
        ),
        4 to listOf(
            p(0, 0, "Väinämöinen kohtaa Ainon", "Väinämöinen meets Aino"),
            p(20, 23, "Aino juoksee kotiin", "Aino runs home"),
            p(116, 132, "Äiti näyttää morsiuskorut", "Her mother shows the bridal finery"),
            p(188, 214, "Aino torjuu avioliiton", "Aino refuses the marriage"),
            p(254, 290, "Aino lähtee metsään ja veteen", "Aino goes to the forest and water"),
            p(370, 422, "Jänis vie suruviestin", "The hare carries the sorrowful news"),
            p(434, 495, "Äidin itku", "The mother's lament"),
        ),
        5 to listOf(
            p(0, 0, "Väinämöinen kalastaa Ainoa", "Väinämöinen fishes for Aino"),
            p(72, 78, "Kala paljastaa henkilöllisyytensä", "The fish reveals her identity"),
            p(133, 144, "Turha etsintä", "The fruitless search"),
            p(163, 177, "Äidin neuvo Pohjolan kosintaan", "His mother's counsel to woo in Pohjola"),
        ),
        6 to listOf(
            p(0, 0, "Joukahainen valmistaa jousen ja väijyy", "Joukahainen makes his bow and lies in wait"),
            p(78, 83, "Väinämöinen saapuu näkyviin", "Väinämöinen comes into view"),
            p(182, 194, "Kolmas nuoli kaataa hevosen", "The third arrow brings down the horse"),
            p(214, 229, "Joukahaisen riemu ja äidin nuhde", "Joukahainen boasts and his mother rebukes him"),
        ),
        7 to listOf(
            p(0, 0, "Väinämöinen ajelehtii merellä", "Väinämöinen drifts on the sea"),
            p(88, 94, "Kokko kantaa Väinämöisen Pohjolaan", "The eagle carries him to Pohjola"),
            p(274, 292, "Louhi lupaa kotiinpaluun Sammosta", "Louhi offers passage home for the Sampo"),
            p(322, 343, "Ilmarinen luvataan Sammon takojaksi", "Ilmarinen is promised as forger of the Sampo"),
        ),
        8 to listOf(
            p(0, 0, "Pohjolan neito istuu sateenkaarella", "The Maiden of Pohjola sits on the rainbow"),
            p(50, 50, "Neito asettaa mahdottomat tehtävät", "The maiden sets impossible tasks"),
            p(132, 132, "Kirves haavoittaa Väinämöistä", "The axe wounds Väinämöinen"),
            p(204, 204, "Parantajan etsintä", "The search for a healer"),
        ),
        9 to listOf(
            p(0, 0, "Raudan synty", "The origin of iron"),
            p(266, 262, "Raudan nuhde ja verensulku", "Iron is rebuked and the bleeding stopped"),
            p(416, 410, "Voiteen valmistus ja paraneminen", "The salve and healing"),
        ),
        10 to listOf(
            p(0, 0, "Väinämöinen houkuttelee Ilmarista", "Väinämöinen urges Ilmarinen to go"),
            p(100, 107, "Ilmarinen kuljetetaan Pohjolaan", "Ilmarinen is carried to Pohjola"),
            p(200, 214, "Ilmarinen otetaan vastaan", "Ilmarinen is welcomed"),
            p(280, 300, "Sammon takominen", "The forging of the Sampo"),
            p(432, 463, "Pohjolan neito kieltäytyy", "The Maiden of Pohjola refuses"),
            p(462, 496, "Ilmarinen palaa kotiin", "Ilmarinen returns home"),
        ),
        11 to listOf(
            p(0, 0, "Lemminkäinen saapuu Saareen", "Lemminkäinen comes to Saari"),
            p(110, 121, "Saaren neidot lämpenevät", "The island maidens warm to him"),
            p(156, 172, "Kyllikin ryöstö", "The abduction of Kyllikki"),
            p(222, 245, "Kyllikin ja Lemminkäisen valat", "Kyllikki and Lemminkäinen exchange vows"),
            p(314, 347, "Kotiinpaluu", "The homecoming"),
        ),
        12 to listOf(
            p(0, 0, "Rikottu vala", "The broken vow"),
            p(128, 133, "Äidin varoitus ja verinen suka", "His mother's warning and the bleeding brush"),
            p(212, 221, "Matka Pohjolaan ja mahtilaulu", "The journey and magic singing at Pohjola"),
        ),
        13 to listOf(
            p(0, 0, "Hiiden hirvi ansiotyöksi", "The Elk of Hiisi as an ordeal"),
            p(30, 33, "Epäonninen hirvenhiihto", "The failed elk hunt"),
        ),
        14 to listOf(
            p(0, 0, "Metsänväki auttaa hirvenpyynnissä", "The forest powers aid the elk hunt"),
            p(270, 288, "Hiiden tulinen hevonen", "The fiery horse of Hiisi"),
            p(372, 397, "Tuonelan joutsen ja Lemminkäisen kuolema", "The Swan of Tuonela and Lemminkäinen's death"),
        ),
        15 to listOf(
            p(0, 0, "Suka vuotaa verta", "The hairbrush bleeds"),
            p(100, 109, "Louhi ja aurinko paljastavat kohtalon", "Louhi and the sun reveal his fate"),
            p(194, 211, "Äiti kokoaa ja herättää poikansa", "A mother restores her son"),
            p(554, 603, "Lemminkäinen kertoo kuolemastaan", "Lemminkäinen recounts his death"),
        ),
        16 to listOf(
            p(0, 0, "Veneestä puuttuu kolme sanaa", "Three words are missing from the boat"),
            p(118, 132, "Matka Tuonelaan", "The journey to Tuonela"),
            p(362, 405, "Pako ja varoitus", "Escape and warning"),
        ),
        17 to listOf(
            p(0, 0, "Vipunen herätetään", "Vipunen is awakened"),
            p(98, 90, "Vipunen nielee Väinämöisen", "Vipunen swallows Väinämöinen"),
            p(146, 134, "Kamppailu puuttuvista sanoista", "The struggle for the missing words"),
            p(526, 484, "Vipusen tieto ja valmis vene", "Vipunen's wisdom and the finished boat"),
        ),
        18 to listOf(
            p(0, 0, "Väinämöinen purjehtii kosintaan", "Väinämöinen sails to woo"),
            p(40, 41, "Annikki näkee veneen", "Annikki sees the boat"),
            p(266, 271, "Ilmarinen valmistautuu kilpakosintaan", "Ilmarinen prepares for the rival courtship"),
            p(470, 479, "Louhi neuvoo tytärtään", "Louhi advises her daughter"),
            p(634, 647, "Neito valitsee Ilmarisen", "The maiden chooses Ilmarinen"),
        ),
        19 to listOf(
            p(0, 0, "Ilmarinen saapuu ja saa tehtävät", "Ilmarinen arrives and receives the tasks"),
            p(32, 33, "Ilmarisen kolme ansiotyötä", "Ilmarinen's three ordeals"),
            p(344, 359, "Kihlaus", "The betrothal"),
            p(498, 519, "Väinämöinen palaa yksin", "Väinämöinen returns alone"),
        ),
        20 to listOf(
            p(0, 0, "Suuren härän teurastus", "The slaughter of the great ox"),
            p(118, 123, "Oluen synty ja hääpidot", "The origin of ale and the wedding feast"),
            p(516, 536, "Hääkutsut — paitsi Lemminkäiselle", "Wedding invitations — except Lemminkäinen"),
        ),
        21 to listOf(
            p(0, 0, "Sulhasväki otetaan vastaan", "The bridegroom's party is welcomed"),
            p(226, 218, "Hääateria", "The wedding meal"),
            p(252, 243, "Väinämöisen kiitoslaulu", "Väinämöinen's song of praise"),
        ),
        22 to listOf(
            p(0, 0, "Morsianta valmistetaan lähtöön", "The bride is prepared to leave"),
            p(124, 118, "Morsiamen suru", "The bride's sorrow"),
            p(184, 175, "Jäähyväisten raskaus", "The weight of farewell"),
            p(382, 363, "Morsian itkee", "The bride laments"),
            p(448, 426, "Morsianta lohdutetaan", "The bride is comforted"),
        ),
        23 to listOf(
            p(0, 0, "Ohjeita uudelle miniälle", "Counsel for the new bride"),
            p(478, 474, "Kulkurivaimon varoittava kertomus", "The old wanderer's cautionary tale"),
        ),
        24 to listOf(
            p(0, 0, "Ohjeita sulhaselle", "Counsel for the bridegroom"),
            p(264, 254, "Kerjäläisukon kertomus", "The old beggar's tale"),
            p(296, 285, "Morsiamen jäähyväiset", "The bride's farewell"),
            p(462, 445, "Matka Ilmarisen kotiin", "The journey to Ilmarinen's home"),
        ),
        25 to listOf(
            p(0, 0, "Hääväki saapuu Ilmarisen kotiin", "The wedding party reaches Ilmarinen's home"),
            p(382, 338, "Pidot ja kiitoslaulut", "Feasting and songs of praise"),
            p(672, 595, "Väinämöinen korjaa rekensä", "Väinämöinen repairs his sledge"),
        ),
        26 to listOf(
            p(0, 0, "Lemminkäinen päättää lähteä pitoihin", "Lemminkäinen resolves to attend the feast"),
            p(382, 371, "Vaarojen läpi Pohjolaan", "Through the dangers to Pohjola"),
        ),
        27 to listOf(
            p(0, 0, "Kutsumaton vieras", "The uninvited guest"),
            p(204, 197, "Pohjolan isännän haaste", "The Lord of Pohjola's challenge"),
            p(282, 273, "Kaksintaistelu ja pakeneva Lemminkäinen", "The duel and Lemminkäinen's flight"),
        ),
        28 to listOf(
            p(0, 0, "Pako Pohjolasta", "The flight from Pohjola"),
            p(164, 165, "Äiti etsii piilopaikan", "His mother seeks a hiding place"),
        ),
        29 to listOf(
            p(0, 0, "Purjehdus turvasaarelle", "The voyage to the island refuge"),
            p(180, 179, "Elämä Saaren naisten parissa", "Life among the island women"),
            p(290, 288, "Pako Saaresta", "The flight from the island"),
            p(402, 399, "Haaksirikko ja paluu", "Shipwreck and return"),
            p(452, 448, "Poltettu kotipiha", "The burned homestead"),
            p(514, 510, "Äiti löytyy elossa", "His mother is found alive"),
            p(546, 541, "Lupaus rakentaa ja kostaa", "A promise to rebuild and avenge"),
        ),
        30 to listOf(
            p(0, 0, "Tiera lähtee sotaretkelle", "Tiera joins the war expedition"),
            p(122, 118, "Pakkanen pysäyttää veneen", "Frost stops the boat"),
            p(316, 305, "Jään yli kotiin", "Homeward across the ice"),
        ),
        31 to listOf(
            p(0, 0, "Untamon ja Kalervon sota", "The war of Untamo and Kalervo"),
            p(82, 81, "Kullervoa ei voida surmata", "Kullervo cannot be killed"),
            p(202, 200, "Pilatut työt ja orjaksi myynti", "Ruined tasks and sale into slavery"),
        ),
        32 to listOf(
            p(0, 0, "Kivikakku ja karjapaimen", "The stone loaf and the herdsman"),
            p(32, 27, "Karjan suojelusanat", "Charms for protecting the cattle"),
        ),
        33 to listOf(
            p(0, 0, "Perintöveitsi särkyy", "The heirloom knife breaks"),
            p(98, 90, "Kullervo kokoaa petokarjan", "Kullervo gathers a herd of beasts"),
            p(184, 168, "Ilmarisen emännän kuolema", "The death of Ilmarinen's wife"),
        ),
        34 to listOf(
            p(0, 0, "Pako ja metsän vanha vaimo", "Flight and the old woman of the forest"),
            p(128, 123, "Kadonnut perhe löytyy", "The lost family is found"),
            p(188, 181, "Äiti kertoo kadonneesta tyttärestä", "His mother tells of the missing daughter"),
        ),
        35 to listOf(
            p(0, 0, "Kullervon epäonnistuneet työt", "Kullervo's failed labors"),
            p(68, 65, "Kohtaaminen kadonneen sisaren kanssa", "The meeting with his lost sister"),
            p(188, 181, "Totuus ja sisaren kuolema", "Recognition and the sister's death"),
            p(344, 331, "Kullervo valitsee koston", "Kullervo chooses revenge"),
        ),
        36 to listOf(
            p(0, 0, "Lähtö sotaan", "Departure for war"),
            p(154, 144, "Untamolan hävitys", "The destruction of Untamola"),
            p(250, 233, "Tyhjä kotipiha", "The deserted homestead"),
            p(296, 276, "Kullervon kuolema", "The death of Kullervo"),
        ),
        37 to listOf(
            p(0, 0, "Kultamorsiamen takominen", "The forging of the golden bride"),
            p(162, 150, "Kylmä yö", "The cold night"),
            p(196, 182, "Väinämöinen torjuu kultakuvan", "Väinämöinen refuses the golden image"),
        ),
        38 to listOf(
            p(0, 0, "Uusi kosinta ja neidon ryöstö", "A new courtship and abduction"),
            p(124, 108, "Riita matkalla ja lokiksi laulaminen", "The quarrel and transformation into a gull"),
            p(286, 249, "Ilmarinen kertoo Sammon vauraudesta", "Ilmarinen tells of the Sampo's prosperity"),
        ),
        39 to listOf(
            p(0, 0, "Suunnitelma Sammon ryöstöstä", "The plan to recover the Sampo"),
            p(330, 313, "Lemminkäinen liittyy retkeen", "Lemminkäinen joins the expedition"),
        ),
        40 to listOf(
            p(0, 0, "Vene tarttuu jättiläishaukeen", "The boat catches on the giant pike"),
            p(93, 88, "Hauki surmataan ja syödään", "The pike is killed and eaten"),
            p(204, 192, "Hauen leukaluusta kantele", "A kantele from the pike's jawbone"),
        ),
        41 to listOf(
            p(0, 0, "Koko luomakunta kuuntelee", "All creation listens"),
            p(168, 151, "Kyyneleet muuttuvat helmiksi", "Tears become pearls"),
        ),
        42 to listOf(
            p(0, 0, "Väinämöinen vaatii Sampoa", "Väinämöinen demands the Sampo"),
            p(58, 52, "Louhi kieltäytyy", "Louhi refuses"),
            p(64, 58, "Pohjola nukutetaan ja Sampo viedään", "Pohjola is lulled to sleep and the Sampo taken"),
            p(164, 147, "Kotimatka Sammon kanssa", "The homeward voyage with the Sampo"),
            p(308, 277, "Louhen vastatoimet ja kadonnut kantele", "Louhi's obstacles and the lost kantele"),
        ),
        43 to listOf(
            p(0, 0, "Pohjolan sotalaiva ajaa takaa", "Pohjola's warship gives chase"),
            p(22, 19, "Taistelu merellä", "The battle at sea"),
            p(258, 224, "Sampo putoaa ja särkyy", "The Sampo falls and breaks"),
            p(266, 230, "Sammon palat ajautuvat rantaan", "Fragments of the Sampo wash ashore"),
            p(304, 263, "Louhen uhkaukset", "Louhi's threats"),
            p(368, 319, "Louhi palaa Pohjolaan", "Louhi returns to Pohjola"),
            p(384, 333, "Väinämöinen kylvää Sammon murut", "Väinämöinen plants the Sampo fragments"),
        ),
        44 to listOf(
            p(0, 0, "Kadonneen kanteleen etsintä", "The search for the lost kantele"),
            p(76, 67, "Koivukantele ja uusi soitto", "The birch kantele and new music"),
        ),
        45 to listOf(
            p(0, 0, "Louhi lähettää taudit", "Louhi sends the diseases"),
            p(190, 151, "Väinämöinen parantaa kansan", "Väinämöinen heals the people"),
        ),
        46 to listOf(
            p(0, 0, "Louhi nostattaa karhun", "Louhi sends the bear"),
            p(20, 17, "Karhunpyynti ja peijaiset", "The bear hunt and feast"),
            p(606, 527, "Väinämöisen laulu tulevasta onnesta", "Väinämöinen sings of future happiness"),
        ),
        47 to listOf(
            p(0, 0, "Kuu, aurinko ja tuli ryöstetään", "Moon, sun, and fire are stolen"),
            p(40, 39, "Ukko iskee uuden tulen", "Ukko kindles a new fire"),
            p(82, 80, "Väinämöinen ja Ilmarinen etsivät tulta", "Väinämöinen and Ilmarinen seek the fire"),
            p(126, 123, "Ilman impi kertoo kalan nielaisseen tulen", "The Air Maiden tells of the fire-swallowing fish"),
            p(312, 304, "Tuohinuotta ei riitä", "The bast net fails"),
        ),
        48 to listOf(
            p(0, 0, "Pellavanuotta pyytää tulikalan", "The linen net catches the fire-fish"),
            p(192, 165, "Tuli polttaa Ilmarisen", "The fire burns Ilmarinen"),
            p(248, 213, "Tuli karkaa metsiin", "The fire escapes into the forests"),
            p(290, 249, "Tuli palautetaan ja Ilmarinen paranee", "The fire is restored and Ilmarinen heals"),
        ),
        49 to listOf(
            p(0, 0, "Taotut kuu ja aurinko eivät loista", "The forged moon and sun do not shine"),
            p(74, 78, "Arpa paljastaa Pohjolan vankilan", "Divination reveals their prison in Pohjola"),
            p(230, 244, "Vuoren lukot eivät aukea", "The mountain's locks will not open"),
            p(278, 294, "Ilmarinen takoo työkalut ja Louhi taipuu", "Ilmarinen forges tools and Louhi relents"),
            p(362, 383, "Väinämöinen tervehtii palanneita valoja", "Väinämöinen greets the restored lights"),
        ),
        50 to listOf(
            p(0, 0, "Marjatta, puolukka ja lapsen syntymä", "Marjatta, the berry, and the child's birth"),
            p(346, 283, "Kadonnut lapsi löytyy suolta", "The lost child is found in the marsh"),
            p(430, 352, "Kaste viivästyy", "The baptism is delayed"),
            p(440, 360, "Lapsi nuhtelee Väinämöistä", "The child rebukes Väinämöinen"),
            p(474, 388, "Uusi kuningas ja Väinämöisen lähtö", "The new king and Väinämöinen's departure"),
            p(512, 419, "Runonlaulajan loppusanat", "The singer's concluding words"),
        ),
    )

    fun sectionsFor(rune: Rune, language: LanguagePack): List<RuneSection> {
        if (rune.lines.isEmpty()) return emptyList()
        val specs = byRune[rune.number].orEmpty()
        if (specs.isEmpty()) return listOf(RuneSection(0, rune.title, rune.title))

        val base = specs.mapNotNull { spec ->
            val raw = (if (language == LanguagePack.Finnish) spec.fiStart else spec.enStart)
                ?: return@mapNotNull null
            raw.coerceIn(0, rune.lines.lastIndex) to spec
        }.distinctBy { it.first }.sortedBy { it.first }.toMutableList()
        if (base.first().first != 0) base.add(0, 0 to base.first().second)

        return buildList {
            base.forEachIndexed { index, (start, spec) ->
                val end = base.getOrNull(index + 1)?.first ?: rune.lines.size
                val length = (end - start).coerceAtLeast(1)
                val chunks = ceil(length / maxLinesPerPart.toDouble()).toInt().coerceAtLeast(1)
                repeat(chunks) { chunk ->
                    val rawStart = start + (length * chunk.toDouble() / chunks).roundToInt()
                    val actualStart = if (chunk == 0) start else (rawStart / 2 * 2)
                        .coerceIn((lastOrNull()?.startLine ?: -1) + 1, end - 1)
                    val baseTitle = spec.title(language)
                    val title = if (chunks == 1) baseTitle else "$baseTitle · ${chunk + 1}/$chunks"
                    if (actualStart < end && (lastOrNull()?.startLine ?: -1) < actualStart) {
                        add(
                            RuneSection(
                                actualStart,
                                title,
                                SectionSummaries.forSection(rune.number, spec.fiStart, language) ?: baseTitle,
                            ),
                        )
                    }
                }
            }
        }
    }

}
