package com.elvispillinen.kalevala.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.ThemeMode
import com.elvispillinen.kalevala.ui.components.HannunvaakunaDivider
import com.elvispillinen.kalevala.ui.components.LanguageChips
import com.elvispillinen.kalevala.ui.uiText
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    viewModel: KalevalaViewModel,
    contentPadding: PaddingValues,
) {
    val language = viewModel.language
    val context = LocalContext.current
    Box(Modifier.fillMaxSize().padding(contentPadding), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Text(uiText(language, "Asetukset", "Settings"), style = MaterialTheme.typography.headlineLarge)
                Text(uiText(language, "Kieli ja lukukokemus", "Language and reading experience"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                SectionTitle(uiText(language, "Teoksen kieli", "Text language"))
                LanguageChips(language, viewModel::selectLanguage)
                Text(
                    uiText(language, "Molemmat kokonaiset kielipaketit sisältyvät sovellukseen.", "Both complete language packs are included in the app."),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                SectionTitle(uiText(language, "Ulkoasu", "Appearance"))
                ThemeMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.setTheme(mode) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = viewModel.themeMode == mode, onClick = { viewModel.setTheme(mode) })
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(themeName(mode, language), style = MaterialTheme.typography.labelLarge)
                            Text(themeDescription(mode, language), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item {
                SectionTitle(uiText(language, "Tekstin koko", "Text size"))
                Text("${(viewModel.fontScale * 100).roundToInt()} %", style = MaterialTheme.typography.labelLarge)
                Slider(value = viewModel.fontScale, onValueChange = viewModel::updateFontScale, valueRange = 0.8f..1.5f, steps = 6)
            }
            item {
                SectionTitle(uiText(language, "Riviväli", "Line spacing"))
                Text("${(viewModel.lineSpacing * 100).roundToInt()} %", style = MaterialTheme.typography.labelLarge)
                Slider(value = viewModel.lineSpacing, onValueChange = viewModel::updateLineSpacing, valueRange = 1.05f..1.8f, steps = 6)
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle(uiText(language, "Näytä säenumerot", "Show line numbers"))
                        Text(uiText(language, "Helpottaa viittaamista ja muistiinpanoja.", "Makes references and notes easier."), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = viewModel.showLineNumbers, onCheckedChange = viewModel::updateShowLineNumbers)
                }
            }
            item { HannunvaakunaDivider() }
            item {
                SectionTitle(uiText(language, "Tietosuoja ja offline-käyttö", "Privacy and offline use"))
                InfoRow(Icons.Outlined.CloudOff, uiText(language, "Tekstit, haku ja hakemisto toimivat ilman internetiä.", "Texts, search, and the guide work without internet."))
                InfoRow(Icons.Outlined.PrivacyTip, uiText(language, "Ei tiliä, mainoksia, analytiikkaa tai käyttäjän seurantaa.", "No account, ads, analytics, or user tracking."))
                InfoRow(Icons.Outlined.Verified, uiText(language, "Edistyminen, kirjanmerkit ja muistiinpanot tallentuvat vain laitteelle ja sen varmuuskopioon.", "Progress, bookmarks, and notes stay on the device and its backup."))
            }
            item {
                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(uiText(language, "Tekstilähteet", "Text sources"), style = MaterialTheme.typography.titleLarge)
                        Text(
                            uiText(language, "Suomi: vuoden 1849 Kalevala, SKS:n 28. painokseen perustuva Project Gutenberg -teksti nro 7000.", "Finnish: 1849 Kalevala, Project Gutenberg text no. 7000 based on the Finnish Literature Society's 28th printing."),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text(
                            uiText(language, "English: John Martin Crawfordin käännös, Project Gutenberg nro 5186.", "English: John Martin Crawford translation, Project Gutenberg no. 5186."),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text(
                            uiText(language, "Runojen osajako seuraa W. F. Kirbyn vuoden 1907 laitoksen juonirajoja; englanninkieliset rajat on sovitettu Crawfordin käännökseen.", "Rune parts follow the narrative ranges in W. F. Kirby's 1907 edition; English boundaries are adapted to Crawford's translation."),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        HorizontalDivider()
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gutenberg.org/ebooks/7000"))) }) { Text("#7000") }
                            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gutenberg.org/ebooks/5186"))) }) { Text("#5186") }
                        }
                    }
                }
            }
            item {
                Text("Kalevala 1.2.1", style = MaterialTheme.typography.labelLarge)
                Text(
                    uiText(language, "Tekijä: Trassel Vardias", "Created by Trassel Vardias"),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
                Text(
                    uiText(language, "Avoin, mainokseton lukusovellus. Tekstit ovat tekijänoikeudesta vapaita; sovelluskoodi julkaistaan Apache-2.0-lisenssillä.", "An open, ad-free reading app. The texts are public domain; app code is released under Apache License 2.0."),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Text(text, modifier = Modifier.padding(start = 12.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

private fun themeName(mode: ThemeMode, language: LanguagePack): String = when (mode) {
    ThemeMode.System -> uiText(language, "Järjestelmä", "System")
    ThemeMode.Parchment -> uiText(language, "Pergamentti", "Parchment")
    ThemeMode.Night -> uiText(language, "Yö", "Night")
}

private fun themeDescription(mode: ThemeMode, language: LanguagePack): String = when (mode) {
    ThemeMode.System -> uiText(language, "Seuraa puhelimen vaaleaa tai tummaa tilaa", "Follow the phone's light or dark mode")
    ThemeMode.Parchment -> uiText(language, "Lämmin vaalea lukutila", "Warm light reading mode")
    ThemeMode.Night -> uiText(language, "Rauhallinen tumma lukutila", "Calm dark reading mode")
}
