package com.elvispillinen.kalevala.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.NavigateBefore
import androidx.compose.material.icons.automirrored.outlined.NavigateNext
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.StopCircle
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.Bookmark
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.Narrator
import com.elvispillinen.kalevala.data.ReferenceCatalog
import com.elvispillinen.kalevala.data.ReferenceCategory
import com.elvispillinen.kalevala.data.Rune
import com.elvispillinen.kalevala.data.RuneSections
import com.elvispillinen.kalevala.ui.components.HannunvaakunaDivider
import com.elvispillinen.kalevala.ui.other
import com.elvispillinen.kalevala.ui.uiText
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReaderScreen(
    viewModel: KalevalaViewModel,
    language: LanguagePack,
    runeNumber: Int,
    initialLine: Int,
    onBack: () -> Unit,
    onNavigate: (LanguagePack, Int, Int) -> Unit,
) {
    val context = LocalContext.current
    val rune = remember(language, runeNumber) { viewModel.repository.rune(language, runeNumber) }
    val safeInitialLine = initialLine.coerceIn(0, rune.lines.lastIndex.coerceAtLeast(0))
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = safeInitialLine + 1)
    val scope = rememberCoroutineScope()
    val narrator = remember { Narrator(context) }
    val sections = remember(rune, language) { RuneSections.sectionsFor(rune, language) }
    val sectionsByStart = remember(sections) {
        sections.withIndex().associateBy({ it.value.startLine }, { it })
    }
    var selectedLine by rememberSaveable(language.code, runeNumber) { mutableIntStateOf(-1) }
    val currentLine by remember(listState, rune.lines) {
        derivedStateOf {
            (listState.firstVisibleItemIndex - 1)
                .coerceIn(0, rune.lines.lastIndex.coerceAtLeast(0))
        }
    }
    val currentSectionIndex by remember(currentLine, sections) {
        derivedStateOf { sections.indexOfLast { it.startLine <= currentLine }.coerceAtLeast(0) }
    }

    DisposableEffect(narrator) { onDispose { narrator.close() } }
    LaunchedEffect(language, runeNumber, listState) {
        snapshotFlow { (listState.firstVisibleItemIndex - 1).coerceAtLeast(0) }
            .distinctUntilChanged()
            .collect { line -> viewModel.savePosition(language, runeNumber, line.coerceAtMost(rune.lines.lastIndex)) }
    }

    fun switchLanguage() {
        val targetLanguage = language.other
        val targetRune = viewModel.repository.rune(targetLanguage, runeNumber)
        val fraction = currentLine.toFloat() / rune.lines.size.coerceAtLeast(1)
        val targetLine = (fraction * targetRune.lines.size).toInt().coerceIn(0, targetRune.lines.lastIndex)
        narrator.stop()
        viewModel.selectLanguage(targetLanguage)
        onNavigate(targetLanguage, runeNumber, targetLine)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(rune.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            language.nativeName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, uiText(language, "Takaisin", "Back"))
                    }
                },
                actions = {
                    TextButton(onClick = ::switchLanguage) { Text(language.other.code.uppercase()) }
                    IconButton(onClick = { viewModel.toggleFavourite(language, runeNumber) }) {
                        Icon(
                            if (viewModel.isFavourite(language, runeNumber)) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            uiText(language, "Suosikkiruno", "Favorite rune"),
                            tint = MaterialTheme.colorScheme.tertiary,
                        )
                    }
                    IconButton(
                        enabled = narrator.isReady,
                        onClick = {
                            if (narrator.isSpeaking) narrator.stop() else {
                                narrator.speak(rune.lines, language, currentLine)
                                if (!narrator.languageAvailable) {
                                    Toast.makeText(
                                        context,
                                        uiText(language, "Laitteessa ei ole tämän kielen puheääntä.", "No speech voice for this language is installed."),
                                        Toast.LENGTH_LONG,
                                    ).show()
                                }
                            }
                        },
                    ) {
                        Icon(
                            if (narrator.isSpeaking) Icons.Outlined.StopCircle else Icons.AutoMirrored.Outlined.VolumeUp,
                            uiText(language, "Lue ääneen", "Read aloud"),
                        )
                    }
                },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        enabled = runeNumber > 1,
                        onClick = { narrator.stop(); onNavigate(language, runeNumber - 1, 0) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.AutoMirrored.Outlined.NavigateBefore, null)
                        Text(uiText(language, "Edellinen", "Previous"))
                    }
                    Text(
                        "${runeNumber} / 50",
                        modifier = Modifier.width(72.dp),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelLarge,
                    )
                    TextButton(
                        enabled = runeNumber < 50,
                        onClick = { narrator.stop(); onNavigate(language, runeNumber + 1, 0) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(uiText(language, "Seuraava", "Next"))
                        Icon(Icons.AutoMirrored.Outlined.NavigateNext, null)
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
            ) {
                item(key = "header") {
                    val arc = viewModel.storyArcs.firstOrNull { runeNumber in it.runes }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            uiText(language, "RUNO $runeNumber", "RUNE $runeNumber"),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary,
                        )
                        Text(rune.title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        if (arc != null) {
                            Text(
                                arc.summary(language),
                                modifier = Modifier.padding(top = 8.dp),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                        Text(
                            uiText(language, "Runon osat", "Rune parts"),
                            modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        LazyRow(
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(sections.withIndex().toList(), key = { it.value.startLine }) { indexed ->
                                FilterChip(
                                    selected = indexed.index == currentSectionIndex,
                                    onClick = {
                                        scope.launch { listState.animateScrollToItem(indexed.value.startLine + 1) }
                                    },
                                    label = {
                                        Text(
                                            "${indexed.index + 1}. ${indexed.value.title}",
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    },
                                )
                            }
                        }
                        Text(
                            uiText(
                                language,
                                "Korostusväriset sanat löytyvät Tietäjästä. Avaa säe nähdäksesi vain sen tunnistetut sanat.",
                                "Accent-colored terms are in the Guide. Open a line to see only its recognized terms.",
                            ),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        HannunvaakunaDivider(Modifier.padding(vertical = 18.dp))
                    }
                }
                itemsIndexed(rune.lines, key = { index, _ -> index }) { index, line ->
                    val bookmarked = viewModel.isBookmarked(language, runeNumber, index)
                    val section = sectionsByStart[index]
                    val keywordColor = MaterialTheme.colorScheme.secondary
                    val highlightedLine = remember(line, keywordColor) {
                        buildAnnotatedString {
                            append(line)
                            ReferenceCatalog.matchesIn(line).forEach { match ->
                                addStyle(
                                    SpanStyle(
                                        color = keywordColor,
                                        fontWeight = FontWeight.Medium,
                                    ),
                                    start = match.start,
                                    end = match.endExclusive,
                                )
                            }
                        }
                    }
                    Column {
                        if (section != null) {
                            val nextStart = sections.getOrNull(section.index + 1)?.startLine ?: rune.lines.size
                            SectionHeader(
                                language = language,
                                number = section.index + 1,
                                total = sections.size,
                                title = section.value.title,
                                summary = section.value.summary,
                                firstLine = index + 1,
                                lastLine = nextStart,
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { selectedLine = index },
                                    onLongClick = { selectedLine = index },
                                )
                                .padding(vertical = (4 * viewModel.lineSpacing).dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            if (viewModel.showLineNumbers) {
                                Text(
                                    (index + 1).toString(),
                                    modifier = Modifier.width(44.dp).padding(top = 3.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.End,
                                )
                                Spacer(Modifier.width(12.dp))
                            }
                            Text(
                                highlightedLine,
                                modifier = Modifier.weight(1f),
                                fontSize = (18f * viewModel.fontScale).sp,
                                lineHeight = (18f * viewModel.fontScale * viewModel.lineSpacing).sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            if (bookmarked) {
                                Icon(
                                    Icons.Filled.Bookmark,
                                    uiText(language, "Kirjanmerkki", "Bookmark"),
                                    modifier = Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.tertiary,
                                )
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }

    if (selectedLine >= 0) {
        LineToolsSheet(
            viewModel = viewModel,
            language = language,
            rune = rune,
            lineIndex = selectedLine,
            onDismiss = { selectedLine = -1 },
        )
    }
}

@Composable
private fun SectionHeader(
    language: LanguagePack,
    number: Int,
    total: Int,
    title: String,
    summary: String,
    firstLine: Int,
    lastLine: Int,
) {
    var expanded by rememberSaveable(title) { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp, bottom = 12.dp)
            .clickable { expanded = !expanded },
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp).animateContentSize()) {
            Text(
                uiText(
                    language,
                    "OSA $number/$total · SÄKEET $firstLine–$lastLine",
                    "PART $number/$total · LINES $firstLine–$lastLine",
                ),
                style = MaterialTheme.typography.labelLarge,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(top = 3.dp))
                Icon(
                    if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    uiText(language, if (expanded) "Piilota yhteenveto" else "Näytä yhteenveto", if (expanded) "Hide summary" else "Show summary"),
                )
            }
            if (expanded) {
                Text(
                    summary,
                    modifier = Modifier.padding(top = 9.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.82f),
                )
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun LineToolsSheet(
    viewModel: KalevalaViewModel,
    language: LanguagePack,
    rune: Rune,
    lineIndex: Int,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val line = rune.lines[lineIndex]
    val key = Bookmark(language, rune.number, lineIndex).key
    val existing = viewModel.bookmarks.firstOrNull { it.key == key }
    var note by rememberSaveable(key) { mutableStateOf(existing?.note.orEmpty()) }
    val recognized = remember(line) {
        ReferenceCatalog.matchesIn(line).distinctBy { it.entry.id }
    }
    var lookupId by rememberSaveable(key) {
        mutableStateOf(recognized.singleOrNull()?.entry?.id)
    }
    val lookup = recognized.firstOrNull { it.entry.id == lookupId }?.entry

    ModalBottomSheet(onDismissRequest = onDismiss) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().widthIn(max = 760.dp).align(Alignment.CenterHorizontally),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    uiText(language, "RUNO ${rune.number} · SÄE ${lineIndex + 1}", "RUNE ${rune.number} · LINE ${lineIndex + 1}"),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary,
                )
                Text("“$line”", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 6.dp))
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        AssistChip(
                            onClick = { viewModel.toggleBookmark(language, rune.number, lineIndex) },
                            leadingIcon = { Icon(if (viewModel.isBookmarked(language, rune.number, lineIndex)) Icons.Filled.Bookmark else Icons.Outlined.BookmarkAdd, null) },
                            label = { Text(if (viewModel.isBookmarked(language, rune.number, lineIndex)) uiText(language, "Tallennettu", "Saved") else uiText(language, "Tallenna", "Save")) },
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                clipboard.setText(AnnotatedString(line))
                                Toast.makeText(context, uiText(language, "Säe kopioitu", "Line copied"), Toast.LENGTH_SHORT).show()
                            },
                            leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) },
                            label = { Text(uiText(language, "Kopioi", "Copy")) },
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                val label = uiText(language, "Kalevala, runo ${rune.number}, säe ${lineIndex + 1}", "Kalevala, Rune ${rune.number}, line ${lineIndex + 1}")
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "“$line”\n— $label")
                                }
                                context.startActivity(Intent.createChooser(intent, uiText(language, "Jaa säe", "Share line")))
                            },
                            leadingIcon = { Icon(Icons.Outlined.Share, null) },
                            label = { Text(uiText(language, "Jaa", "Share")) },
                        )
                    }
                }
            }
            item {
                HorizontalDivider()
                Text(
                    uiText(language, "Tietäjästä löytyvät sanat", "Terms found in the Guide"),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp),
                )
                if (recognized.isEmpty()) {
                    Text(
                        uiText(
                            language,
                            "Tässä säkeessä ei ole vielä Tietäjä-artikkeliin yhdistettyä sanaa.",
                            "This line does not yet contain a term linked to a Guide article.",
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        uiText(
                            language,
                            "Valitse korostettu sana. Tavallisia sanoja ei näytetä turhaan painikkeina.",
                            "Choose a highlighted term. Ordinary words are not shown as inactive buttons.",
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        items(recognized, key = { it.entry.id }) { match ->
                            FilterChip(
                                selected = lookupId == match.entry.id,
                                onClick = { lookupId = match.entry.id },
                                label = { Text(match.surface) },
                            )
                        }
                    }
                }
            }
            lookup?.let { selectedEntry ->
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(
                                lineCategoryName(selectedEntry.category, language),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary,
                            )
                            Text(selectedEntry.name(language), style = MaterialTheme.typography.titleMedium)
                            Text(selectedEntry.short(language), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            if (selectedEntry.detail(language) != selectedEntry.short(language)) {
                                Text(
                                    selectedEntry.detail(language),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            selectedEntry.runes?.let { range ->
                                Text(
                                    if (range.first == range.last) {
                                        uiText(language, "Liittyvä runo: ${range.first}", "Related rune: ${range.first}")
                                    } else {
                                        uiText(language, "Liittyvät runot: ${range.first}–${range.last}", "Related runes: ${range.first}–${range.last}")
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(uiText(language, "Oma muistiinpano", "Personal note")) },
                    minLines = 2,
                    maxLines = 5,
                )
                Button(
                    onClick = {
                        viewModel.saveBookmarkNote(language, rune.number, lineIndex, note)
                        Toast.makeText(context, uiText(language, "Muistiinpano tallennettu", "Note saved"), Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                ) {
                    Text(uiText(language, "Tallenna muistiinpano", "Save note"))
                }
            }
        }
    }
}

private fun lineCategoryName(category: ReferenceCategory, language: LanguagePack): String = when (category) {
    ReferenceCategory.Character -> uiText(language, "Henkilö", "Character")
    ReferenceCategory.Place -> uiText(language, "Paikka", "Place")
    ReferenceCategory.Object -> uiText(language, "Esine", "Object")
    ReferenceCategory.Concept -> uiText(language, "Käsite", "Concept")
    ReferenceCategory.Word -> uiText(language, "Vanha sana", "Old word")
    ReferenceCategory.Symbol -> uiText(language, "Symboli", "Symbol")
}
