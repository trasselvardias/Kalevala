package com.elvispillinen.kalevala.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.SearchNormalizer
import com.elvispillinen.kalevala.ui.components.HannunvaakunaDivider
import com.elvispillinen.kalevala.ui.components.LanguageChips
import com.elvispillinen.kalevala.ui.uiText

@Composable
fun RuneListScreen(
    viewModel: KalevalaViewModel,
    contentPadding: PaddingValues,
    onOpenRune: (LanguagePack, Int, Int) -> Unit,
) {
    val language = viewModel.language
    val corpus = remember(language) { viewModel.repository.corpus(language) }
    val position = viewModel.position(language)
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, corpus) {
        if (query.isBlank()) corpus.runes else corpus.runes.filter { rune ->
            rune.number.toString() == query.trim() || SearchNormalizer.matches(rune.title, query)
        }
    }

    Box(Modifier.fillMaxSize().padding(contentPadding), contentAlignment = Alignment.TopCenter) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 340.dp),
            modifier = Modifier.fillMaxSize().widthIn(max = 1100.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        uiText(language, "Viisikymmentä runoa", "Fifty runes"),
                        style = MaterialTheme.typography.headlineLarge,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        uiText(language, "Valitse runo tai jatka siitä, mihin jäit.", "Choose a rune or continue where you left off."),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    LanguageChips(language, viewModel::selectLanguage, Modifier.padding(top = 8.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(uiText(language, "Etsi numerolla tai nimellä", "Find by number or title")) },
                        singleLine = true,
                    )
                    HannunvaakunaDivider(Modifier.padding(top = 14.dp))
                }
            }

            items(filtered, key = { it.number }) { rune ->
                val arc = viewModel.storyArcs.firstOrNull { rune.number in it.runes }
                val isCurrent = position.runeNumber == rune.number
                Card(onClick = { onOpenRune(language, rune.number, if (isCurrent) position.lineIndex else 0) }) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp)) {
                        Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 42.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    uiText(language, "RUNO ${rune.number}", "RUNE ${rune.number}"),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isCurrent) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center,
                                )
                                Text(rune.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                                if (arc != null) {
                                    Text(
                                        arc.title(language),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                    )
                                }
                                Text(
                                    uiText(language, "${rune.lines.size} säettä", "${rune.lines.size} lines"),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                )
                            }
                            IconButton(
                                onClick = { viewModel.toggleFavourite(language, rune.number) },
                                modifier = Modifier.align(Alignment.TopEnd),
                            ) {
                                Icon(
                                    if (viewModel.isFavourite(language, rune.number)) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = uiText(language, "Merkitse suosikiksi", "Mark as favorite"),
                                    tint = MaterialTheme.colorScheme.tertiary,
                                )
                            }
                        }
                        if (isCurrent) {
                            LinearProgressIndicator(
                                progress = { position.lineIndex.toFloat() / rune.lines.size.coerceAtLeast(1) },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, start = 18.dp, end = 18.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
