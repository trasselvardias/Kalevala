package com.elvispillinen.kalevala.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.automirrored.outlined.ManageSearch
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.ui.screens.BookmarksScreen
import com.elvispillinen.kalevala.ui.screens.HomeScreen
import com.elvispillinen.kalevala.ui.screens.ReaderScreen
import com.elvispillinen.kalevala.ui.screens.ReferenceDetailScreen
import com.elvispillinen.kalevala.ui.screens.ReferenceScreen
import com.elvispillinen.kalevala.ui.screens.RuneListScreen
import com.elvispillinen.kalevala.ui.screens.SearchScreen
import com.elvispillinen.kalevala.ui.screens.SettingsScreen

private data class MainDestination(
    val route: String,
    val fiLabel: String,
    val enLabel: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
)

private val destinations = listOf(
    MainDestination("home", "Koti", "Home", Icons.Outlined.Home),
    MainDestination("runes", "Runot", "Runes", Icons.AutoMirrored.Outlined.MenuBook),
    MainDestination("search", "Haku", "Search", Icons.AutoMirrored.Outlined.ManageSearch),
    MainDestination("reference", "Tietäjä", "Guide", Icons.Outlined.AutoStories),
    MainDestination("settings", "Asetukset", "Settings", Icons.Outlined.Settings),
)

@Composable
fun KalevalaApp(viewModel: KalevalaViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBottomBar = destinations.any { it.route == route }

    fun openReader(language: LanguagePack, rune: Int, line: Int = 0) {
        navController.navigate("reader/${language.code}/${rune.coerceIn(1, 50)}?line=${line.coerceAtLeast(0)}")
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    destinations.forEach { destination ->
                        NavigationBarItem(
                            selected = route == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(destination.icon, contentDescription = null) },
                            label = { Text(uiText(viewModel.language, destination.fiLabel, destination.enLabel)) },
                        )
                    }
                }
            }
        },
    ) { contentPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier,
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    contentPadding = contentPadding,
                    onRead = ::openReader,
                    onRunes = { navController.navigate("runes") },
                    onSearch = { navController.navigate("search") },
                    onReference = { navController.navigate("reference") },
                    onBookmarks = { navController.navigate("bookmarks") },
                )
            }
            composable("runes") {
                RuneListScreen(viewModel, contentPadding, ::openReader)
            }
            composable("search") {
                SearchScreen(
                    viewModel = viewModel,
                    contentPadding = contentPadding,
                    onOpenResult = ::openReader,
                    onOpenReference = { navController.navigate("reference/$it") },
                )
            }
            composable("reference") {
                ReferenceScreen(
                    viewModel = viewModel,
                    contentPadding = contentPadding,
                    onOpenEntry = { navController.navigate("reference/$it") },
                )
            }
            composable("settings") {
                SettingsScreen(viewModel, contentPadding)
            }
            composable("bookmarks") {
                BookmarksScreen(
                    viewModel = viewModel,
                    onBack = navController::navigateUp,
                    onOpen = ::openReader,
                )
            }
            composable(
                route = "reader/{language}/{rune}?line={line}",
                arguments = listOf(
                    navArgument("language") { type = NavType.StringType },
                    navArgument("rune") { type = NavType.IntType },
                    navArgument("line") { type = NavType.IntType; defaultValue = 0 },
                ),
            ) { entry ->
                ReaderScreen(
                    viewModel = viewModel,
                    language = LanguagePack.fromCode(entry.arguments?.getString("language")),
                    runeNumber = entry.arguments?.getInt("rune") ?: 1,
                    initialLine = entry.arguments?.getInt("line") ?: 0,
                    onBack = navController::navigateUp,
                    onNavigate = ::openReader,
                )
            }
            composable(
                route = "reference/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val item = viewModel.references.firstOrNull { it.id == id }
                if (item != null) {
                    ReferenceDetailScreen(
                        entry = item,
                        language = viewModel.language,
                        onBack = navController::navigateUp,
                        onOpenRune = { openReader(viewModel.language, it) },
                    )
                }
            }
        }
    }
}
