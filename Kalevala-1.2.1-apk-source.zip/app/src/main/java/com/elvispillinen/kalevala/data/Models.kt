package com.elvispillinen.kalevala.data

enum class LanguagePack(
    val code: String,
    val nativeName: String,
    val assetName: String,
    val ttsTag: String,
) {
    Finnish("fi", "Suomi", "kalevala_fi.json", "fi-FI"),
    English("en", "English", "kalevala_en.json", "en-US");

    companion object {
        fun fromCode(code: String?): LanguagePack = entries.firstOrNull { it.code == code } ?: Finnish
    }
}

data class Rune(
    val number: Int,
    val title: String,
    val lines: List<String>,
)

/** A semantic reading part within one rune. Line numbers are zero based. */
data class RuneSection(
    val startLine: Int,
    val title: String,
    val summary: String,
)

data class BilingualRuneSection(
    val runeNumber: Int,
    val finnishStartLine: Int,
    val englishStartLine: Int?,
    val title: LocalizedText,
    val summary: LocalizedText,
)

/** One word in a verse that has an entry in [ReferenceCatalog]. */
data class ReferenceMatch(
    val start: Int,
    val endExclusive: Int,
    val surface: String,
    val entry: ReferenceEntry,
)

data class Corpus(
    val language: LanguagePack,
    val work: String,
    val sourceNote: String,
    val sourceUrl: String,
    val sourceSha256: String,
    val runes: List<Rune>,
) {
    val lineCount: Int = runes.sumOf { it.lines.size }
}

data class SearchHit(
    val language: LanguagePack,
    val runeNumber: Int,
    val runeTitle: String,
    val lineIndex: Int,
    val line: String,
)

data class ReaderPosition(
    val language: LanguagePack,
    val runeNumber: Int,
    val lineIndex: Int,
)

data class Bookmark(
    val language: LanguagePack,
    val runeNumber: Int,
    val lineIndex: Int,
    val note: String = "",
) {
    val key: String get() = "${language.code}|$runeNumber|$lineIndex"
}

enum class ReferenceCategory { Character, Place, Object, Concept, Word, Symbol }

data class LocalizedText(val fi: String, val en: String) {
    operator fun invoke(language: LanguagePack): String = if (language == LanguagePack.Finnish) fi else en
}

data class ReferenceEntry(
    val id: String,
    val name: LocalizedText,
    val category: ReferenceCategory,
    val short: LocalizedText,
    val detail: LocalizedText,
    val aliases: List<String> = emptyList(),
    val runes: IntRange? = null,
    val historicallySensitive: Boolean = false,
)

data class StoryArc(
    val runes: IntRange,
    val title: LocalizedText,
    val summary: LocalizedText,
)

enum class ThemeMode { System, Parchment, Night }
