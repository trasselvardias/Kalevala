package com.elvispillinen.kalevala.data

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

class KalevalaRepository(private val context: Context) {
    private val cache = mutableMapOf<LanguagePack, Corpus>()

    fun corpus(language: LanguagePack): Corpus = synchronized(cache) {
        cache.getOrPut(language) { loadCorpus(language) }
    }

    fun rune(language: LanguagePack, number: Int): Rune =
        corpus(language).runes[(number - 1).coerceIn(0, 49)]

    fun search(
        query: String,
        languages: Collection<LanguagePack>,
        limit: Int = 150,
    ): List<SearchHit> {
        val needle = SearchNormalizer.normalize(query)
        if (needle.length < 2) return emptyList()
        val hits = ArrayList<SearchHit>(minOf(limit, 64))
        for (language in languages) {
            for (rune in corpus(language).runes) {
                rune.lines.forEachIndexed { index, line ->
                    if (SearchNormalizer.normalize(line).contains(needle)) {
                        hits += SearchHit(language, rune.number, rune.title, index, line)
                        if (hits.size == limit) return hits
                    }
                }
            }
        }
        return hits
    }

    fun dailyVerse(language: LanguagePack, date: LocalDate = LocalDate.now()): SearchHit {
        val anchor = DailyVerseCatalog.anchorFor(date)
        val rune = rune(language, anchor.runeNumber)
        val lineIndex = anchor.lineIndex(language).coerceIn(0, rune.lines.lastIndex)
        return SearchHit(language, rune.number, rune.title, lineIndex, rune.lines[lineIndex])
    }

    private fun loadCorpus(language: LanguagePack): Corpus {
        val json = context.assets.open(language.assetName).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(json)
        val array = root.getJSONArray("runes")
        val runes = buildList(array.length()) {
            for (runeIndex in 0 until array.length()) {
                val item = array.getJSONObject(runeIndex)
                val linesJson = item.getJSONArray("lines")
                val lines = buildList(linesJson.length()) {
                    for (lineIndex in 0 until linesJson.length()) add(linesJson.getString(lineIndex))
                }
                add(Rune(item.getInt("number"), item.getString("title"), lines))
            }
        }
        require(runes.size == 50) { "${language.nativeName} pack must contain exactly 50 runes" }
        return Corpus(
            language = language,
            work = root.getString("work"),
            sourceNote = root.getString("sourceNote"),
            sourceUrl = root.getString("sourceUrl"),
            sourceSha256 = root.getString("sourceSha256"),
            runes = runes,
        )
    }
}
