package com.elvispillinen.kalevala.data

import java.time.LocalDate

/**
 * Stable bilingual anchors for the daily verse.
 *
 * Crawford's translation is not line-for-line with the Finnish edition, so a
 * shared numeric line index can point to unrelated text. Each rune therefore
 * has one checked pair of corresponding opening lines. Runes 1 and 49 need
 * different offsets because the English source omits or adds transition lines.
 */
object DailyVerseCatalog {
    data class Anchor(
        val runeNumber: Int,
        val finnishLineIndex: Int,
        val englishLineIndex: Int,
    ) {
        fun lineIndex(language: LanguagePack): Int =
            if (language == LanguagePack.Finnish) finnishLineIndex else englishLineIndex
    }

    private val anchors = (1..50).map { runeNumber ->
        when (runeNumber) {
            1 -> Anchor(runeNumber, finnishLineIndex = 110, englishLineIndex = 0)
            49 -> Anchor(runeNumber, finnishLineIndex = 1, englishLineIndex = 1)
            else -> Anchor(runeNumber, finnishLineIndex = 0, englishLineIndex = 0)
        }
    }

    fun anchorFor(date: LocalDate): Anchor {
        val index = Math.floorMod(date.toEpochDay() * 37L, anchors.size.toLong()).toInt()
        return anchors[index]
    }

    fun bilingualAnchors(): List<Anchor> = anchors
}
