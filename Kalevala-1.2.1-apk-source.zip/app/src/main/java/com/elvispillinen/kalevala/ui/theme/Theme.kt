package com.elvispillinen.kalevala.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.elvispillinen.kalevala.data.ThemeMode

val Pine = Color(0xFF173B34)
val PineLight = Color(0xFF2E5E53)
val Gold = Color(0xFFC99C3A)
val Parchment = Color(0xFFF4E8CD)
val ParchmentLight = Color(0xFFFFF8E8)
val Ink = Color(0xFF261E17)
val Rust = Color(0xFF8C3F2B)
val Night = Color(0xFF0D1816)
val NightSurface = Color(0xFF172622)
val Moon = Color(0xFFE7D9BB)

private val ParchmentScheme = lightColorScheme(
    primary = Pine,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC9E8DD),
    onPrimaryContainer = Color(0xFF09251F),
    secondary = Rust,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDBCF),
    onSecondaryContainer = Color(0xFF351007),
    tertiary = Gold,
    onTertiary = Color(0xFF382B00),
    background = Parchment,
    onBackground = Ink,
    surface = ParchmentLight,
    onSurface = Ink,
    surfaceVariant = Color(0xFFE9DCC2),
    onSurfaceVariant = Color(0xFF51483B),
    outline = Color(0xFF817565),
)

private val NightScheme = darkColorScheme(
    primary = Color(0xFF93D3C2),
    onPrimary = Color(0xFF00382F),
    primaryContainer = Pine,
    onPrimaryContainer = Color(0xFFB0F0DF),
    secondary = Color(0xFFFFB59F),
    onSecondary = Color(0xFF561F11),
    secondaryContainer = Color(0xFF733522),
    onSecondaryContainer = Color(0xFFFFDBD0),
    tertiary = Color(0xFFE5C15E),
    onTertiary = Color(0xFF3B2F00),
    background = Night,
    onBackground = Moon,
    surface = NightSurface,
    onSurface = Moon,
    surfaceVariant = Color(0xFF283A35),
    onSurfaceVariant = Color(0xFFC4CEC8),
    outline = Color(0xFF89948F),
)

private val KalevalaTypography = androidx.compose.material3.Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 48.sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 32.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 27.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 23.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 21.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Serif, fontSize = 18.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 15.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
)

@Composable
fun KalevalaTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Parchment -> false
        ThemeMode.Night -> true
    }
    val scheme = if (dark) NightScheme else ParchmentScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = KalevalaTypography, content = content)
}
