package com.elvispillinen.kalevala.data

import android.content.Context

class UserPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("kalevala_reader", Context.MODE_PRIVATE)

    var selectedLanguage: LanguagePack
        get() = LanguagePack.fromCode(prefs.getString("language", LanguagePack.Finnish.code))
        set(value) = prefs.edit().putString("language", value.code).apply()

    var themeMode: ThemeMode
        get() = runCatching {
            ThemeMode.valueOf(prefs.getString("theme", ThemeMode.System.name) ?: ThemeMode.System.name)
        }.getOrDefault(ThemeMode.System)
        set(value) = prefs.edit().putString("theme", value.name).apply()

    var fontScale: Float
        get() = prefs.getFloat("font_scale", 1f).coerceIn(0.8f, 1.5f)
        set(value) = prefs.edit().putFloat("font_scale", value.coerceIn(0.8f, 1.5f)).apply()

    var lineSpacing: Float
        get() = prefs.getFloat("line_spacing", 1.35f).coerceIn(1.05f, 1.8f)
        set(value) = prefs.edit().putFloat("line_spacing", value.coerceIn(1.05f, 1.8f)).apply()

    var showLineNumbers: Boolean
        get() = prefs.getBoolean("line_numbers", false)
        set(value) = prefs.edit().putBoolean("line_numbers", value).apply()

    fun position(language: LanguagePack): ReaderPosition {
        val rune = prefs.getInt("position_${language.code}_rune", 1).coerceIn(1, 50)
        val line = prefs.getInt("position_${language.code}_line", 0).coerceAtLeast(0)
        return ReaderPosition(language, rune, line)
    }

    fun savePosition(position: ReaderPosition) {
        prefs.edit()
            .putInt("position_${position.language.code}_rune", position.runeNumber.coerceIn(1, 50))
            .putInt("position_${position.language.code}_line", position.lineIndex.coerceAtLeast(0))
            .apply()
    }

    fun bookmarks(): Set<Bookmark> = prefs.getStringSet("bookmarks", emptySet()).orEmpty()
        .mapNotNull(::decodeBookmark)
        .toSet()

    fun saveBookmarks(bookmarks: Set<Bookmark>) {
        prefs.edit().putStringSet("bookmarks", bookmarks.map { it.key }.toSet()).apply()
        bookmarks.forEach { bookmark ->
            if (bookmark.note.isNotBlank()) prefs.edit().putString("note_${bookmark.key}", bookmark.note).apply()
        }
    }

    fun noteFor(key: String): String = prefs.getString("note_$key", "").orEmpty()

    fun saveNote(key: String, note: String) {
        prefs.edit().putString("note_$key", note.trim()).apply()
    }

    fun favouriteRunes(): Set<String> = prefs.getStringSet("favourite_runes", emptySet()).orEmpty()

    fun saveFavouriteRunes(value: Set<String>) {
        prefs.edit().putStringSet("favourite_runes", value).apply()
    }

    private fun decodeBookmark(raw: String): Bookmark? {
        val pieces = raw.split('|')
        if (pieces.size != 3) return null
        val language = LanguagePack.fromCode(pieces[0])
        val rune = pieces[1].toIntOrNull() ?: return null
        val line = pieces[2].toIntOrNull() ?: return null
        return Bookmark(language, rune, line, noteFor(raw))
    }
}
