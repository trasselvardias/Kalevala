package com.elvispillinen.kalevala.data

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

class Narrator(context: Context) : TextToSpeech.OnInitListener {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var engine: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    var isReady by mutableStateOf(false)
        private set
    var isSpeaking by mutableStateOf(false)
        private set
    var languageAvailable by mutableStateOf(true)
        private set

    override fun onInit(status: Int) {
        isReady = status == TextToSpeech.SUCCESS
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                mainHandler.post { isSpeaking = true }
            }
            override fun onDone(utteranceId: String?) {
                if (utteranceId?.endsWith("_last") == true) mainHandler.post { isSpeaking = false }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post { isSpeaking = false }
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post { isSpeaking = false }
            }
        })
    }

    fun speak(lines: List<String>, language: LanguagePack, startLine: Int = 0) {
        val tts = engine ?: return
        if (!isReady) return
        val locale = Locale.forLanguageTag(language.ttsTag)
        val availability = tts.isLanguageAvailable(locale)
        languageAvailable = availability >= TextToSpeech.LANG_AVAILABLE
        if (!languageAvailable) return
        tts.language = locale
        val chunks = speechChunks(lines.drop(startLine.coerceIn(0, lines.size)))
        if (chunks.isEmpty()) return
        chunks.forEachIndexed { index, chunk ->
            val last = index == chunks.lastIndex
            val id = "kalevala_${System.nanoTime()}_${index}${if (last) "_last" else ""}"
            tts.speak(
                chunk,
                if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                Bundle(),
                id,
            )
        }
    }

    fun stop() {
        engine?.stop()
        isSpeaking = false
    }

    fun close() {
        stop()
        engine?.shutdown()
        engine = null
        isReady = false
    }

    companion object {
        internal fun speechChunks(lines: List<String>, maxLength: Int = 2800): List<String> {
            if (lines.isEmpty()) return emptyList()
            val chunks = mutableListOf<String>()
            val current = StringBuilder()
            lines.forEach { line ->
                val safe = line.trim()
                if (safe.isEmpty()) return@forEach
                if (current.isNotEmpty() && current.length + safe.length + 2 > maxLength) {
                    chunks += current.toString()
                    current.clear()
                }
                if (safe.length > maxLength) {
                    safe.chunked(maxLength).forEach { part ->
                        if (current.isNotEmpty()) {
                            chunks += current.toString()
                            current.clear()
                        }
                        chunks += part
                    }
                } else {
                    if (current.isNotEmpty()) current.append(". ")
                    current.append(safe)
                }
            }
            if (current.isNotEmpty()) chunks += current.toString()
            return chunks
        }
    }
}
