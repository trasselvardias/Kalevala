package com.elvispillinen.kalevala.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.automirrored.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.TipsAndUpdates
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elvispillinen.kalevala.KalevalaViewModel
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.StoryArc
import com.elvispillinen.kalevala.ui.components.HannunvaakunaDivider
import com.elvispillinen.kalevala.ui.components.RunonlaulajaMark
import com.elvispillinen.kalevala.ui.uiText

@Composable
fun HomeScreen(
    viewModel: KalevalaViewModel,
    contentPadding: PaddingValues,
    onRead: (LanguagePack, Int, Int) -> Unit,
    onRunes: () -> Unit,
    onSearch: () -> Unit,
    onReference: () -> Unit,
    onBookmarks: () -> Unit,
) {
    val language = viewModel.language
    val corpus = remember(language) { viewModel.repository.corpus(language) }
    val position = viewModel.position(language)
    val currentRune = corpus.runes[position.runeNumber - 1]
    val daily = remember(language) { viewModel.repository.dailyVerse(language) }
    val overallProgress = ((position.runeNumber - 1) +
        position.lineIndex.toFloat() / currentRune.lines.size.coerceAtLeast(1)) / 50f

    Box(Modifier.fillMaxSize().padding(contentPadding), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 840.dp),
            contentPadding = PaddingValues(bottom = 28.dp),
        ) {
            item {
                Surface(color = MaterialTheme.colorScheme.primary) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        RunonlaulajaMark(
                            modifier = Modifier.fillMaxWidth(0.52f),
                            contentDescription = uiText(language, "Runonlaulajan kädet", "Runo-singer's hands"),
                        )
                        Text(
                            "KALEVALA",
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.headlineLarge,
                            letterSpacing = 2.sp,
                        )
                        Text(
                            uiText(language, "Viisikymmentä runoa – aina mukanasi", "Fifty runes – always with you"),
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f),
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }

            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                uiText(language, "Jatka lukemista", "Continue reading"),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary,
                            )
                            Text(currentRune.title, style = MaterialTheme.typography.titleLarge)
                            Text(
                                uiText(language, "Säe ${position.lineIndex + 1}", "Line ${position.lineIndex + 1}"),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Button(onClick = { onRead(language, position.runeNumber, position.lineIndex) }) {
                            Text(uiText(language, "Jatka", "Resume"))
                            Icon(Icons.Outlined.ChevronRight, contentDescription = null)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { overallProgress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "${(overallProgress * 100).toInt()} %",
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.End,
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    QuickAction(
                        modifier = Modifier.weight(1f),
                        icon = { Icon(Icons.AutoMirrored.Outlined.LibraryBooks, contentDescription = null) },
                        label = uiText(language, "Runot", "Runes"),
                        onClick = onRunes,
                    )
                    QuickAction(
                        modifier = Modifier.weight(1f),
                        icon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                        label = uiText(language, "Haku", "Search"),
                        onClick = onSearch,
                    )
                    QuickAction(
                        modifier = Modifier.weight(1f),
                        icon = { Icon(Icons.Outlined.TipsAndUpdates, contentDescription = null) },
                        label = uiText(language, "Tietäjä", "Guide"),
                        onClick = onReference,
                    )
                    QuickAction(
                        modifier = Modifier.weight(1f),
                        icon = { Icon(Icons.Outlined.Bookmarks, contentDescription = null) },
                        label = uiText(language, "Merkit", "Saved"),
                        onClick = onBookmarks,
                    )
                }
            }

            item {
                HannunvaakunaDivider(Modifier.padding(horizontal = 24.dp, vertical = 22.dp))
            }

            item {
                Text(
                    uiText(language, "Päivän säe", "Verse of the day"),
                    modifier = Modifier.padding(horizontal = 20.dp),
                    style = MaterialTheme.typography.headlineSmall,
                )
                ElevatedCard(
                    onClick = { onRead(daily.language, daily.runeNumber, daily.lineIndex) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "“${daily.line}”",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium,
                        )
                        Text(
                            "${daily.runeTitle} · ${uiText(language, "säe", "line")} ${daily.lineIndex + 1}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            item {
                Text(
                    uiText(language, "Kertomuksen polku", "Story path"),
                    modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp),
                    style = MaterialTheme.typography.headlineSmall,
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(viewModel.storyArcs) { arc ->
                        StoryArcCard(arc, language) { onRead(language, arc.runes.first, 0) }
                    }
                }
            }

            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(
                        Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(uiText(language, "Koko teos offline", "The complete work, offline"), style = MaterialTheme.typography.titleMedium)
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Stat("50", uiText(language, "runoa", "runes"))
                            Stat(corpus.lineCount.toString(), uiText(language, "säettä", "lines"))
                            Stat("0", uiText(language, "mainosta", "ads"))
                        }
                        OutlinedButton(onClick = {
                            viewModel.selectLanguage(if (language == LanguagePack.Finnish) LanguagePack.English else LanguagePack.Finnish)
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(uiText(language, "Vaihda englanninkieliseen Kalevalaan", "Switch to the Finnish Kalevala"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    modifier: Modifier,
    icon: @Composable () -> Unit,
    label: String,
    onClick: () -> Unit,
) {
    ElevatedCard(onClick = onClick, modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            icon()
            Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

@Composable
private fun StoryArcCard(arc: StoryArc, language: LanguagePack, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.widthIn(min = 250.dp, max = 290.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                uiText(language, "Runot ${arc.runes.first}–${arc.runes.last}", "Runes ${arc.runes.first}–${arc.runes.last}"),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary,
            )
            Text(arc.title(language), style = MaterialTheme.typography.titleMedium)
            Text(arc.summary(language), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
