package com.elvispillinen.kalevala

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.elvispillinen.kalevala.data.Bookmark
import com.elvispillinen.kalevala.data.KalevalaRepository
import com.elvispillinen.kalevala.data.LanguagePack
import com.elvispillinen.kalevala.data.ReaderPosition
import com.elvispillinen.kalevala.data.ReferenceCatalog
import com.elvispillinen.kalevala.data.SearchHit
import com.elvispillinen.kalevala.data.StoryGuides
import com.elvispillinen.kalevala.data.ThemeMode
import com.elvispillinen.kalevala.data.UserPreferences

class KalevalaViewModel(application: Application) : AndroidViewModel(application) {
    val repository = KalevalaRepository(application)
    val references = ReferenceCatalog.entries
    val storyArcs = StoryGuides.arcs
    private val preferences = UserPreferences(application)

    var language by mutableStateOf(preferences.selectedLanguage)
        private set
    var themeMode by mutableStateOf(preferences.themeMode)
        private set
    var fontScale by mutableFloatStateOf(preferences.fontScale)
        private set
    var lineSpacing by mutableFloatStateOf(preferences.lineSpacing)
        private set
    var showLineNumbers by mutableStateOf(preferences.showLineNumbers)
        private set
    var bookmarks by mutableStateOf(preferences.bookmarks())
        private set
    var favouriteRunes by mutableStateOf(preferences.favouriteRunes())
        private set

    fun selectLanguage(value: LanguagePack) {
        language = value
        preferences.selectedLanguage = value
    }

    fun setTheme(value: ThemeMode) {
        themeMode = value
        preferences.themeMode = value
    }

    fun updateFontScale(value: Float) {
        fontScale = value.coerceIn(0.8f, 1.5f)
        preferences.fontScale = fontScale
    }

    fun updateLineSpacing(value: Float) {
        lineSpacing = value.coerceIn(1.05f, 1.8f)
        preferences.lineSpacing = lineSpacing
    }

    fun updateShowLineNumbers(value: Boolean) {
        showLineNumbers = value
        preferences.showLineNumbers = value
    }

    fun position(language: LanguagePack = this.language): ReaderPosition = preferences.position(language)

    fun savePosition(language: LanguagePack, rune: Int, line: Int) {
        preferences.savePosition(ReaderPosition(language, rune, line))
    }

    fun isBookmarked(language: LanguagePack, rune: Int, line: Int): Boolean =
        bookmarks.any { it.language == language && it.runeNumber == rune && it.lineIndex == line }

    fun toggleBookmark(language: LanguagePack, rune: Int, line: Int) {
        val existing = bookmarks.firstOrNull {
            it.language == language && it.runeNumber == rune && it.lineIndex == line
        }
        bookmarks = if (existing == null) {
            bookmarks + Bookmark(language, rune, line)
        } else {
            bookmarks - existing
        }
        preferences.saveBookmarks(bookmarks)
    }

    fun saveBookmarkNote(language: LanguagePack, rune: Int, line: Int, note: String) {
        val key = Bookmark(language, rune, line).key
        if (!isBookmarked(language, rune, line)) toggleBookmark(language, rune, line)
        preferences.saveNote(key, note)
        bookmarks = bookmarks.map {
            if (it.key == key) it.copy(note = note.trim()) else it
        }.toSet()
    }

    fun toggleFavourite(language: LanguagePack, rune: Int) {
        val key = "${language.code}|$rune"
        favouriteRunes = if (key in favouriteRunes) favouriteRunes - key else favouriteRunes + key
        preferences.saveFavouriteRunes(favouriteRunes)
    }

    fun isFavourite(language: LanguagePack, rune: Int): Boolean = "${language.code}|$rune" in favouriteRunes

    fun search(query: String, allLanguages: Boolean): List<SearchHit> = repository.search(
        query,
        if (allLanguages) LanguagePack.entries else listOf(language),
    )
}
