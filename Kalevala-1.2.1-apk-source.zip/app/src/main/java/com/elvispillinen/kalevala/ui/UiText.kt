package com.elvispillinen.kalevala.ui

import com.elvispillinen.kalevala.data.LanguagePack

fun uiText(language: LanguagePack, fi: String, en: String): String =
    if (language == LanguagePack.Finnish) fi else en

val LanguagePack.other: LanguagePack
    get() = if (this == LanguagePack.Finnish) LanguagePack.English else LanguagePack.Finnish
