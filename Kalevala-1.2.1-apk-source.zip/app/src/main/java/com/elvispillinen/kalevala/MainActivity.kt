package com.elvispillinen.kalevala

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.elvispillinen.kalevala.ui.KalevalaApp
import com.elvispillinen.kalevala.ui.theme.KalevalaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KalevalaViewModel = viewModel()
            KalevalaTheme(viewModel.themeMode) {
                KalevalaApp(viewModel)
            }
        }
    }
}
