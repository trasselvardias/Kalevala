#!/usr/bin/env python3
"""Create the checked-in offline Kalevala language packs.

The script deliberately extracts only the literary text. Project Gutenberg
headers, legal boilerplate, tables of contents, prefaces, and the Crawford
glossary are not presented as part of a rune. Source attribution remains in
each generated pack and in the app's About screen.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
SOURCES = {
    "fi": (
        "https://www.gutenberg.org/cache/epub/7000/pg7000.txt",
        "Project Gutenberg eBook 7000; text based on the Finnish Literature "
        "Society's 28th printing of the 1849 Kalevala",
    ),
    "en": (
        "https://www.gutenberg.org/cache/epub/5186/pg5186.txt",
        "Project Gutenberg eBook 5186; John Martin Crawford translation",
    ),
}

FINNISH_ORDINALS = [
    "Ensimmäinen", "Toinen", "Kolmas", "Neljäs", "Viides", "Kuudes",
    "Seitsemäs", "Kahdeksas", "Yhdeksäs", "Kymmenes", "Yhdestoista",
    "Kahdestoista", "Kolmastoista", "Neljästoista", "Viidestoista",
    "Kuudestoista", "Seitsemästoista", "Kahdeksastoista", "Yhdeksästoista",
    "Kahdeskymmenes", "Yhdeskolmatta", "Kahdeskolmatta", "Kolmaskolmatta",
    "Neljäskolmatta", "Viideskolmatta", "Kuudeskolmatta", "Seitsemäskolmatta",
    "Kahdeksaskolmatta", "Yhdeksäskolmatta", "Kolmaskymmenes",
    "Yhdesneljättä", "Kahdesneljättä", "Kolmasneljättä", "Neljäsneljättä",
    "Viidesneljättä", "Kuudesneljättä", "Seitsemäsneljättä",
    "Kahdeksasneljättä", "Yhdeksäsneljättä", "Neljäskymmenes",
    "Yhdesviidettä", "Kahdesviidettä", "Kolmasviidettä", "Neljäsviidettä",
    "Viidesviidettä", "Kuudesviidettä", "Seitsemäsviidettä",
    "Kahdeksasviidettä", "Yhdeksäsviidettä", "Viideskymmenes",
]


def read_source(language: str, local_path: Path | None) -> tuple[str, str]:
    url, _ = SOURCES[language]
    if local_path:
        payload = local_path.read_bytes()
    else:
        request = urllib.request.Request(url, headers={"User-Agent": "KalevalaAppBuilder/1.0"})
        with urllib.request.urlopen(request, timeout=60) as response:
            payload = response.read()
    return payload.decode("utf-8-sig").replace("\r\n", "\n"), hashlib.sha256(payload).hexdigest()


def clean_verse(line: str) -> str:
    return line.strip().replace("\u00a0", " ")


def parse_finnish(text: str) -> list[dict]:
    heading_pattern = re.compile(r"^\s*(.+ runo)\s*$", re.IGNORECASE)
    headings: list[tuple[int, str]] = []
    lines = text.splitlines()
    valid = {f"{ordinal} runo".lower() for ordinal in FINNISH_ORDINALS}
    for index, line in enumerate(lines):
        match = heading_pattern.match(line)
        if match and match.group(1).lower() in valid:
            headings.append((index, clean_verse(match.group(1))))

    if len(headings) != 50:
        raise ValueError(f"Expected 50 Finnish runos, found {len(headings)}")

    runos = []
    for offset, (start, title) in enumerate(headings):
        end = headings[offset + 1][0] if offset + 1 < len(headings) else next(
            i for i in range(start + 1, len(lines)) if lines[i].startswith("*** END OF")
        )
        verses = [clean_verse(line) for line in lines[start + 1 : end] if clean_verse(line)]
        runos.append({"number": offset + 1, "title": title, "lines": verses})
    return runos


def parse_english(text: str) -> list[dict]:
    lines = text.splitlines()
    heading_pattern = re.compile(r"^RUNE ([IVXLCDM]+)\.$")
    headings = [(i, match.group(1)) for i, line in enumerate(lines) if (match := heading_pattern.match(line.strip()))]
    if len(headings) != 50:
        raise ValueError(f"Expected 50 English runes, found {len(headings)}")

    runes = []
    for offset, (start, roman) in enumerate(headings):
        end = headings[offset + 1][0] if offset + 1 < len(headings) else next(
            i for i in range(start + 1, len(lines)) if lines[i].strip() == "EPILOGUE"
        )
        cursor = start + 1
        while cursor < end and not clean_verse(lines[cursor]):
            cursor += 1
        title_parts = []
        while cursor < end and clean_verse(lines[cursor]):
            title_parts.append(clean_verse(lines[cursor]).rstrip("."))
            cursor += 1
        title = " ".join(title_parts).title().replace("’S", "’s")
        verses = [clean_verse(line) for line in lines[cursor:end] if clean_verse(line)]
        runes.append({"number": offset + 1, "title": f"Rune {roman}: {title}", "lines": verses})
    return runes


def write_pack(language: str, source_path: Path | None) -> None:
    text, digest = read_source(language, source_path)
    runes = parse_finnish(text) if language == "fi" else parse_english(text)
    payload = {
        "schemaVersion": 1,
        "id": language,
        "name": "Suomi" if language == "fi" else "English",
        "work": "Kalevala (1849)",
        "compiler": "Elias Lönnrot",
        "translator": None if language == "fi" else "John Martin Crawford",
        "sourceUrl": SOURCES[language][0],
        "sourceNote": SOURCES[language][1],
        "sourceSha256": digest,
        "runes": runes,
    }
    destination = ASSETS / f"kalevala_{language}.json"
    destination.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    verse_count = sum(len(rune["lines"]) for rune in runes)
    print(f"{destination.name}: {len(runes)} runes, {verse_count} non-empty lines, {destination.stat().st_size} bytes")


def main() -> None:
    local_fi = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    local_en = Path(sys.argv[2]) if len(sys.argv) > 2 else None
    ASSETS.mkdir(parents=True, exist_ok=True)
    write_pack("fi", local_fi)
    write_pack("en", local_en)


if __name__ == "__main__":
    main()
