#!/usr/bin/env python3
"""Build the static browser edition from the Android app's canonical data files."""
from pathlib import Path
import argparse, json, re, shutil

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',default='build/web');p.add_argument('--apk');a=p.parse_args()
out=ROOT/a.output
if out.exists(): shutil.rmtree(out)
shutil.copytree(ROOT/'web',out)
(out/'data').mkdir(exist_ok=True)
expected_lines={'kalevala_fi.json':22796,'kalevala_en.json':22255}
for name in ('kalevala_fi.json','kalevala_en.json'):
    shutil.copy2(ROOT/'app/src/main/assets'/name,out/'data'/name)
    data=json.loads((out/'data'/name).read_text())
    assert len(data['runes'])==50
    assert sum(len(rune['lines']) for rune in data['runes'])==expected_lines[name]
catalog=json.loads((out/'data/catalog.json').read_text())
assert len(catalog['sections'])==191 and len(catalog['entries'])==208
assert len(catalog['arcs'])==10 and len(catalog['daily'])==50
if a.apk:
    apk=Path(a.apk).resolve(); target=out/'download'/'Kalevala-1.2.1-debug.apk';target.parent.mkdir();shutil.copy2(apk,target)
print(f'Built {out}: 50 Finnish runes, 50 English runes, {len(catalog["entries"])} Guide entries')
