#!/usr/bin/env python3
"""Fail fast if a checked-in language pack is incomplete or malformed."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {"fi": 22796, "en": 22255}

for language, expected_lines in EXPECTED.items():
    path = ROOT / "app" / "src" / "main" / "assets" / f"kalevala_{language}.json"
    pack = json.loads(path.read_text(encoding="utf-8"))
    assert pack["schemaVersion"] == 1
    assert pack["id"] == language
    assert len(pack["runes"]) == 50
    assert [rune["number"] for rune in pack["runes"]] == list(range(1, 51))
    assert all(rune["lines"] and all(line.strip() for line in rune["lines"]) for rune in pack["runes"])
    actual_lines = sum(len(rune["lines"]) for rune in pack["runes"])
    assert actual_lines == expected_lines, (language, actual_lines, expected_lines)
    print(f"{language}: 50 runes, {actual_lines} lines — OK")
